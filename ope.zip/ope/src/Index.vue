<template>
  <div class="page">
    <el-container class="main">
        <el-aside width="200px"><LeftMenu></LeftMenu></el-aside>
        <el-container>
            <el-header>
                <Header></Header>
            </el-header>
            <el-main>
                <router-view></router-view>
            </el-main>
        </el-container>
    </el-container>
  </div>
</template>

<script>
  import Header from './components/Header'
  import LeftMenu from './components/leftMenu'
export default {
  name: 'index',
  data () {
    return {
    }
  },
  components:{
    Header,
    LeftMenu
  }
}
</script>
<style lang="scss" scoped>
    .page {
        height: 100%;
        .el-header{
            padding: 0;
        }
        .main{
            height: 100%;
            background: #EDEEF1;
            .el-aside {
                background: #161B37;
                color: #fff;
            }
        }
    }
</style>

