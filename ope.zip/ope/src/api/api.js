import {get,post,fetch,postParams } from './fetch'
import { ACTIONURL,SERVICE_URL,CHAT_URL,UPLOAD_URL,PARAMURL,SERVER_URL_C,FORMALURL} from './config'
export default {
    getcarousel(params) {
        return get(SERVICE_URL+'iBacManage.action',params);
      },

}

