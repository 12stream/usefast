<template>
    <div id="login">
        <div class="load">
            <h3>欢迎使用梦幻通运营后台</h3>
            <div class="login" >
                <div class="form-group">
                    <input type="tel" class="number" placeholder="用户名" v-model="number"/>
                    <span v-if="number == '' && showNumTitle">用户名不能为空</span>
                </div>
                <div :class="(password=='' && !showPasswordTitle) ? 'form-group' : 'form-group num'">
                    <input type="password" class="password" name="pass_word" placeholder="密码" v-model="password"/>
                    <span v-if="password == '' && showPasswordTitle">密码不能为空</span>
                </div>
                <button type="submit" :class="btnLogin ? 'block non' : 'block'" @click="login" :disabled="btnLogin">登 录</button>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            number:"",
            password:"",
            showNumTitle:false,
            showPasswordTitle:false,
            btnLogin:false
        }
    },
    watch:{
        number(val){
            if(val !== "" && this.password !== "") {
                this.btnLogin = false;
            }else{
                this.btnLogin = true;
            }
        },
        password(val){
            if(val !== "" && this.number !== "") {
                this.btnLogin = false;
            }else{
                this.btnLogin = true;
            }
        }
    },
    methods:{
        login(){
            this.showNumTitle = true;
            this.showPasswordTitle = true;
            if(this.number !== '' && this.password !== ''){
                this.$router.push({path:"/"});
                this.btnLogin = false;
            }else{
                this.btnLogin = true;
            }
        },
    }
}
</script>
<style lang="scss" scoped>
#login {
    width: 400px;
    margin:0 auto;
    padding-top: 10%;
}
.load{
    max-width: 400px;
    padding: 10%; 
    background: url("./assets/bg.jpg") repeat;
    h3 {
        color:#c2a78b;
        font-size: 21px;
        line-height: 1.1;
        font-weight: 600;
        margin-top: 5px;
    }
    .login{
        margin-top: 15px;
        .form-group{
            margin-bottom: 15px;
            input {
                height: 34px;
                font-size: 14px;
                display: block;
                width: 100%;
                padding: 6px 12px;
                color: inherit;
                border: 1px solid #e5e6e7;
                border-radius: 1px;
                background-color: #fff;
                background-image: none;
            }
             span {
                display: inline-block;
                color: #ed5565;
                font-size: 12px;
                margin-top: 5px;
            }
        }
        button {
            background: #fb9437;
            color: #ffffff;
            font-size: 16px;
            display: inline-block;
            width: 100%;
            text-align: center;
            border-radius: 3px;
            padding: 6px 12px;
            font-weight: 400;
            line-height: 1.4;
            margin-bottom: 15px;
            &.non {
                opacity: .65;
            }
        }
    }
}
</style>


