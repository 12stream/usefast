<template>
    <div id="id_check">
        <el-table
        :data="tableData"
        style="width: 100%">
            <el-table-column
            label="用户昵称">
            <template slot-scope="scope">
                <span>{{ scope.row.username}}</span>
            </template>
            </el-table-column>
            <el-table-column
            label="用户类型">
            <template slot-scope="scope">
                <span>{{ scope.row.usertype}}</span>
            </template>
            </el-table-column>
            <el-table-column
            label="姓名">
            <template slot-scope="scope">
                <span>{{ scope.row.name}}</span>
            </template>
            </el-table-column>
            <el-table-column
            label="身份证号">
            <template slot-scope="scope">
                <span>{{ scope.row.idcard}}</span>
            </template>
            </el-table-column>
            <el-table-column
            label="身份证照片">
            <template slot-scope="scope">
                <span>{{ scope.row.idcardimg}}</span>
            </template>
            </el-table-column>
            <el-table-column label="操作">
            <template slot-scope="scope">
                <el-button
                size="mini"
                @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
                <el-button
                size="mini"
                type="danger"
                @click="handleDelete(scope.$index, scope.row)">删除</el-button>
            </template>
            </el-table-column>
        </el-table>
    </div>
</template>
<script>
export default {
    data(){
        return {
            tableData: [
                {
                    username: '用户昵称',
                    usertype: '用户类型',
                    name:'姓名',
                    idcard:'身份证号',
                    idcardimg:'身份证照片'
                }, 
                {
                    username: '用户昵称',
                    usertype: '用户类型',
                    name:'姓名',
                    idcard:'身份证号',
                    idcardimg:'身份证照片'
                },
                {
                    username: '用户昵称',
                    usertype: '用户类型',
                    name:'姓名',
                    idcard:'身份证号',
                    idcardimg:'身份证照片'
                }, 
                {
                    username: '用户昵称',
                    usertype: '用户类型',
                    name:'姓名',
                    idcard:'身份证号',
                    idcardimg:'身份证照片'
            }]
        }
    }
}
</script>
<style lang="scss" scoped>

</style>

