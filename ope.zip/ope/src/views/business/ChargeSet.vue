<template>
    <div id="charge_set">
        <div class="charge-tab">
            <ul>
                <li v-for="(item,i) in tabContents" :key="i" @click="selectTabs(i)" :class="currentWTabsIndex == i ? 'show' : ''">
                    {{item}}
                </li>
            </ul>
        </div>
        <Server v-show="currentWTabsIndex == 0"></Server>
        <Message v-show="currentWTabsIndex == 1"></Message>
    </div>
</template>
<script>
import Server from './components/charge/Server'
import Message from './components/charge/Message'
export default {
    data(){
        return {
            tabContents:['直播服务费','短信费'],
            currentWTabsIndex:0
        }
    },
    components:{Server, Message},
    methods:{
        selectTabs(val){
            this.currentWTabsIndex = val;
        }
    }
}
</script>
<style lang="scss" scoped>
.charge-tab{
    background: #fff;
    border-bottom: 5px solid #ddd;
    ul{
        li{
            display: inline-block;
            padding: 10px 20px 10px 25px;
            color: #a7b1c2;
            font-weight: bold;
            &.show{
                border: 1px solid #ddd;
                border-bottom: 3px solid #35C1FC;
                color: #555;
            }
        }
    }
}
</style>

