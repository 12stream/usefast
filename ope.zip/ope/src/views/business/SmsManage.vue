<template>
    <div id="sms_manage">
        <el-table
        :data="tableData"
        stripe
        style="width: 100%">
            <el-table-column
            prop="order"
            label="序号">
            </el-table-column>
            <el-table-column
            prop="ments"
            label="用户ID">
            </el-table-column>
            <el-table-column
            prop="liveid"
            label="直播间ID">
            </el-table-column>
            <el-table-column
            prop="messagenumber"
            label="发送短信数量">
            </el-table-column>
            <el-table-column
            prop="messagecontent"
            label="短信内容">
            </el-table-column>
            <el-table-column
            prop="creattime"
            label="创建时间">
            </el-table-column>
        </el-table>
    </div>
</template>
<script>
export default {
    data(){
        return {
             tableData: [
                {
                    order:'序号',
                    ments:'用户ID',
                    liveid:'直播间ID',
                    messagenumber:'发送短信数量',
                    messagecontent:'短信内容',
                    creattime:'创建时间'
                }, 
                {
                    order:'序号',
                    ments:'用户ID',
                    liveid:'直播间ID',
                    messagenumber:'发送短信数量',
                    messagecontent:'短信内容',
                    creattime:'创建时间'
                },
                {
                    order:'序号',
                    ments:'用户ID',
                    liveid:'直播间ID',
                    messagenumber:'发送短信数量',
                    messagecontent:'短信内容',
                    creattime:'创建时间'
                }, 
                {
                    order:'序号',
                    ments:'用户ID',
                    liveid:'直播间ID',
                    messagenumber:'发送短信数量',
                    messagecontent:'短信内容',
                    creattime:'创建时间'
            }]
        }
    }
}
</script>
<style lang="scss" scoped>

</style>

