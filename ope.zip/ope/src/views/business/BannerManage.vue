<template>
    <div id="banner_manage">
        <div class="banner-search">
            <el-button type="primary" plain>新增轮播广告</el-button>
        </div>
        <div class="banner-main">
            <el-table
            :data="tableData"
            style="width: 100%">
                <el-table-column
                label="编号"
                width="180">
                <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.serial }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="轮播广告预览"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.link}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="跳转类型"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.type}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="跳转页面链接"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.link}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="排列"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.order}}</span>
                </template>
                </el-table-column>
                <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button
                    size="mini"
                    @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
                    <el-button
                    size="mini"
                    type="danger"
                    @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                </template>
                </el-table-column>
            </el-table>
        </div>
        <!-- 编辑 -->
        <el-dialog title="编辑轮播广告" :visible.sync="globalUserSetVisible">
            <div class="way">
                <span>　　跳转方式：</span>
                <el-select v-model="wayvalue" placeholder="请选择">
                    <el-option
                    v-for="item in wayDate"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </div>
            <div class="jump">
                <span>　　跳转链接：</span>
                <input type="text">
            </div>
            <div class="rand">
                <span>轮播广告排列：</span>
                <input type="text">
            </div>
            <div class="img">
                <span>轮播广告图片：</span>
                <input type="file">
            </div>
        <div slot="footer" class="dialog-footer">
            <el-button @click="globalUserSetVisible = false">取 消</el-button>
            <el-button type="primary" @click="globalUserSetVisible = false">确 定</el-button>
        </div>
        </el-dialog>
    </div>
</template>
<script>
export default {
    data(){
        return {
            globalUserSetVisible:false,
            wayDate:[
                {
                    value: '选项1',
                    label: '直播间'
                },
                {
                    value: '选项2',
                    label: '活动页面'
                },
                {
                    value: '选项3',
                    label: '主播'
                }
            ],
            wayvalue:'活动页面',
            tableData: [
                {
                    serial: '编号',
                    bannerpreview: '轮播广告预览',
                    type:'跳转类型',
                    link:'跳转页面链接',
                    order:'排列'
                }, 
                {
                    serial: '编号',
                    bannerpreview: '轮播广告预览',
                    type:'跳转类型',
                    link:'跳转页面链接',
                    order:'排列'
                },
                {
                    serial: '编号',
                    bannerpreview: '轮播广告预览',
                    type:'跳转类型',
                    link:'跳转页面链接',
                    order:'排列'
                }, 
                {
                    serial: '编号',
                    bannerpreview: '轮播广告预览',
                    type:'跳转类型',
                    link:'跳转页面链接',
                    order:'排列'
            }]
        }
    },
    methods: {
      handleEdit(index, row) {
        this.globalUserSetVisible = true;
        console.log(index, row);
      },
      handleDelete(index, row) {
        console.log(index, row);
      }
    }
}
</script>
<style lang="scss" scoped>
.banner-search{
    padding-top: 20px;
    text-align: right;
    input{
        display: inline-block;
        height: 30px;
        line-height: 30px;
        padding: 0 10px;
    }
    input::-webkit-input-placeholder{
        color:#ccc;
    }
    input::-moz-placeholder{   /* Mozilla Firefox 19+ */
        color:#ccc;
    }
    input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
        color:#ccc;
    }
    input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
        color:#ccc;
    }
}
.banner-main{
    margin-top: 20px;
}
.jump{
    margin: 20px 0;
}
.jump,.rand,.img{
    margin-top: 20px;
    input{
        border: 1px solid #ddd;
        padding: 10px;
        width: 80%;
    }
}
</style>

