<template>
    <div class="library">
        <div class="library-search">
            <el-button type="primary">新增</el-button>
        </div>
        <div class="library-main">
            <el-table
            :data="tableData"
            style="width: 100%">
                <el-table-column
                label="适用对象">
                <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.adaitobject }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="创建时间"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.createtime}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="更新时间"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.changetime}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="牌照水印预览"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.preview}}</span>
                </template>
                </el-table-column>
                <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button
                    size="mini"
                    @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
                    <el-button
                    size="mini"
                    type="danger"
                    @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                </template>
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            tableData: [
                {
                    adaitobject:'适用对象',
                    createtime:'创建时间',
                    changetime:'更新时间',
                    preview:'牌照水印预览'
                }, 
                {
                    adaitobject:'适用对象',
                    createtime:'创建时间',
                    changetime:'更新时间',
                    preview:'牌照水印预览'
                },
                {
                    adaitobject:'适用对象',
                    createtime:'创建时间',
                    changetime:'更新时间',
                    preview:'牌照水印预览'
                }, 
                {
                    adaitobject:'适用对象',
                    createtime:'创建时间',
                    changetime:'修改时间',
                    preview:'牌照水印预览'
            }]
        }
    },
    methods: {
      handleEdit(index, row) {
        console.log(index, row);
      },
      handleDelete(index, row) {
        console.log(index, row);
      }
    }
}
</script>
<style lang="scss" scoped>
.library-search{
    padding-top: 20px;
    text-align: right;
    input{
        display: inline-block;
        height: 30px;
        line-height: 30px;
        padding: 0 10px;
    }
    input::-webkit-input-placeholder{
        color:#ccc;
    }
    input::-moz-placeholder{   /* Mozilla Firefox 19+ */
        color:#ccc;
    }
    input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
        color:#ccc;
    }
    input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
        color:#ccc;
    }
}
.library-main{
    margin-top: 20px;
}
</style>

