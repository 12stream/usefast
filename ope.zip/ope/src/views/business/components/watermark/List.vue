<template>
    <div class="list">
        <div class="list-search">
            <el-button type="primary" @click="addWater">新增</el-button>
        </div>
        <div class="list-main">
            <el-table
            :data="tableData">
                <el-table-column
                label="适用对象"
                width="180">
                <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.adaitobject }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="创建时间">
                <template slot-scope="scope">
                    <span>{{ scope.row.createtime}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="更新时间">
                <template slot-scope="scope">
                    <span>{{ scope.row.changetime}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="牌照水印预览">
                <template slot-scope="scope">
                    <span>{{ scope.row.preview}}</span>
                </template>
                </el-table-column>
                <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button
                    size="mini"
                    @click="handleEdit(scope.$index, scope.row)">修改</el-button>
                    <el-button
                    size="mini"
                    type="danger"
                    @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                </template>
                </el-table-column>
            </el-table>
        </div>
        <!-- 新增 -->
        <el-dialog title="编辑热词" :visible.sync="addwaterVisible">
            <div class="waterword">
                <span>适用对象：</span>
                <el-select v-model="objectvalue" placeholder="请选择">
                    <el-option
                    v-for="item in objectDate"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </div>
            <div class="userid">
                <span>　用户Id：</span>
                <input type="text">
            </div>
            <div class="plate">
                <span>牌照水印：</span>
                <el-select v-model="platevalue" placeholder="请选择">
                    <el-option
                    v-for="item in plateDate"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </div>
        <div slot="footer" class="dialog-footer">
            <el-button @click="addwaterVisible = false">取 消</el-button>
            <el-button type="primary" @click="addwaterVisible = false">确 定</el-button>
        </div>
        </el-dialog>
        <!-- 修改 -->
        <el-dialog title="编辑热词" :visible.sync="waterVisible">
            <div class="waterword">
                <span>适用对象：</span>
                <el-select v-model="objectvalue" placeholder="请选择">
                    <el-option
                    v-for="item in objectDate"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </div>
            <div class="userid">
                <span>　用户Id：</span>
                <input type="text" disabled="disabled">
            </div>
            <div class="plate">
                <span>牌照水印：</span>
                <el-select v-model="platevalue" placeholder="请选择">
                    <el-option
                    v-for="item in plateDate"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </div>
        <div slot="footer" class="dialog-footer">
            <el-button @click="waterVisible = false">取 消</el-button>
            <el-button type="primary" @click="waterVisible = false">确 定</el-button>
        </div>
        </el-dialog>
    </div>
</template>
<script>
export default {
    data(){
        return {
            waterVisible:false,
            addwaterVisible:false,
            objectDate:[
                {
                    value: '选项1',
                    label: '用户'
                }
            ],
            objectvalue:'',
            plateDate:[
                {
                    value: '选项1',
                    label: 'qqq'
                }
            ],
            platevalue:'',
            tableData: [
                {
                    adaitobject:'适用对象',
                    createtime:'创建时间',
                    changetime:'更新时间',
                    preview:'牌照水印预览'
                }, 
                {
                    adaitobject:'适用对象',
                    createtime:'创建时间',
                    changetime:'更新时间',
                    preview:'牌照水印预览'
                },
                {
                    adaitobject:'适用对象',
                    createtime:'创建时间',
                    changetime:'更新时间',
                    preview:'牌照水印预览'
                }, 
                {
                    adaitobject:'适用对象',
                    createtime:'创建时间',
                    changetime:'修改时间',
                    preview:'牌照水印预览'
            }]
        }
    },
    methods: {
      handleEdit(index, row) {
          this.waterVisible = true;
        console.log(index, row);
      },
      handleDelete(index, row) {
        console.log(index, row);
      },
      addWater(){
          this.addwaterVisible = true;
      }
    }
}
</script>
<style lang="scss" scoped>
.list-search{
    padding-top: 20px;
    text-align: right;
    input{
        display: inline-block;
        height: 30px;
        line-height: 30px;
        padding: 0 10px;
    }
    input::-webkit-input-placeholder{
        color:#ccc;
    }
    input::-moz-placeholder{   /* Mozilla Firefox 19+ */
        color:#ccc;
    }
    input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
        color:#ccc;
    }
    input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
        color:#ccc;
    }
}
.list-main{
    margin-top: 20px;
}
.plate,.userid,.waterword{
    margin-top: 20px;
    span{
        margin-right: 20px;
    }
    input{
        border: 1px solid #ddd;
        padding: 10px;
        width: 80%;
    }
}
</style>

