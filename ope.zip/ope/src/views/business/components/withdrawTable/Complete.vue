<template>
    <div class="complete">
        <div class="complete-search">
            日期：
            <el-date-picker
            v-model="time1"
            type="date"
            placeholder="开始时间">
            </el-date-picker>
            <el-date-picker
            v-model="time2"
            type="date"
            placeholder="结束时间">
            </el-date-picker>
            <input type="text" placeholder="请输入关键字筛选">
            <el-button type="primary" plain>查询</el-button>
        </div>
        <div class="complete-main">
            <el-table
            :data="tableData"
            stripe
            style="width: 100%">
                <el-table-column
                prop="ments"
                label="用户ID">
                </el-table-column>
                <el-table-column
                prop="userinfo"
                label="用户昵称">
                </el-table-column>
                <el-table-column
                prop="applytime"
                label="申请时间">
                </el-table-column>
                <el-table-column
                prop="status"
                label="状态">
                </el-table-column>
                <el-table-column
                prop="suctime"
                label="处理时间">
                </el-table-column>
                <el-table-column
                prop="phonenumber"
                label="手机号码">
                </el-table-column>
                <el-table-column
                prop="source"
                label="来源">
                </el-table-column>
                <el-table-column
                prop="message"
                label="需要留言">
                </el-table-column>
                <el-table-column
                prop="extractuser"
                label="提取账户">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            time1:'',
            time2:'',
            tableData: [
                {
                    ments: '用户ID',
                    userinfo: '用户昵称',
                    applytime:'申请时间',
                    status:'2',
                    suctime:'处理时间',
                    phonenumber:'手机号码',
                    source:'来源',
                    message:'需要留言',
                    extractuser:'提取账户'
                }, 
                {
                    ments: '用户ID',
                    userinfo: '用户昵称',
                    applytime:'申请时间',
                    status:'2',
                    suctime:'处理时间',
                    phonenumber:'手机号码',
                    source:'来源',
                    message:'需要留言',
                    extractuser:'提取账户'
                },
                {
                    ments: '用户ID',
                    userinfo: '用户昵称',
                    applytime:'申请时间',
                    status:'2',
                    suctime:'处理时间',
                    phonenumber:'手机号码',
                    source:'来源',
                    message:'需要留言',
                    extractuser:'提取账户'
                }, 
                {
                    ments: '用户ID',
                    userinfo: '用户昵称',
                    applytime:'申请时间',
                    status:'2',
                    suctime:'处理时间',
                    phonenumber:'手机号码',
                    source:'来源',
                    message:'需要留言',
                    extractuser:'提取账户'
            }]
        }
    }
}
</script>
<style lang="scss" scoped>
.complete-search{
    margin-top: 20px;
    text-align: right;
    input{
        display: inline-block;
        height: 30px;
        line-height: 30px;
        padding: 0 10px;
    }
    input::-webkit-input-placeholder{
        color:#ccc;
    }
    input::-moz-placeholder{   /* Mozilla Firefox 19+ */
        color:#ccc;
    }
    input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
        color:#ccc;
    }
    input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
        color:#ccc;
    }
}
.complete-main{
    margin-top: 20px;
}
</style>

