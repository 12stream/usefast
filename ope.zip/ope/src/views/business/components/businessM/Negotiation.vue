<template>
    <div class="negotiation">
        <div class="main">
            <div class="table-tab">
                <ul>
                    <li v-for="(item,i) in tabContents" :key="i" @click="selectTabs(i)" :class="curIndex == i ? 'show' : ''">
                        {{item}}
                    </li>
                </ul>
            </div>
        </div>
        <Wait v-show="curIndex == 0"></Wait>
        <Sucess v-show="curIndex == 1"></Sucess>
        <Ignore v-show="curIndex == 2"></Ignore>
    </div>
</template>
<script>
import Wait from './negotiationTable/Wait'
import Sucess from './negotiationTable/Sucess'
import Ignore from './negotiationTable/Ignore'
export default {
    data(){
        return {
            tabContents:['待处理','已处理','已忽略'],
            curIndex:0
        }
    },
    components:{Wait, Sucess, Ignore},
    methods:{
        selectTabs(val){
            this.curIndex = val;
        }
    }
}
</script>
<style lang="scss" scoped>
.main{
    border-bottom: 1px solid #ddd;
    .table-tab{
        ul{
            li{
                display: inline-block;
                padding: 10px 20px 10px 25px;
                &.show{
                    border: 1px solid #ddd;
                    border-bottom: none;
                }
            }
        }
    }
}
</style>

