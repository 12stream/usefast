<template>
    <div class="sucess">
        <div class="sucess-search clearfix">
            日期：
            <el-date-picker
            v-model="time3"
            type="date"
            placeholder="开始时间">
            </el-date-picker>
            <el-date-picker
            v-model="time4"
            type="date"
            placeholder="结束时间">
            </el-date-picker>
            <input type="text" placeholder="请输入关键字筛选">
            <el-button type="primary" plain>查询</el-button>
        </div>
        <div class="sucess-main">
            <el-table
            :data="tableData"
            stripe
            style="width: 100%">
                <el-table-column
                prop="ments"
                label="用户ID">
                </el-table-column>
                <el-table-column
                prop="userinfo"
                label="用户昵称">
                </el-table-column>
                <el-table-column
                prop="phonenumber"
                label="手机号码">
                </el-table-column>
                <el-table-column
                prop="applytime"
                label="申请时间">
                </el-table-column>
                <el-table-column
                prop="status"
                label="状态">
                </el-table-column>
                <el-table-column
                prop="dealtime"
                label="处理时间">
                </el-table-column>
                <el-table-column
                prop="domain"
                label="现有域名">
                </el-table-column>
                <el-table-column
                prop="domainstatus"
                label="域名使用状态">
                </el-table-column>
                <el-table-column
                prop="startdomain"
                label="原有域名">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            time3:'',
            time4:'',
            tableData: [
                {
                    ments: '用户ID',
                    userinfo: '用户昵称',
                    phonenumber:'手机号码',
                    applytime:'申请时间',
                    status:'2',
                    dealtime:'处理时间',
                    domain:'现有域名',
                    domainstatus:'域名使用状态',
                    startdomain:'原有域名'
                }, 
                {
                    ments: '用户ID',
                    userinfo: '用户昵称',
                    phonenumber:'手机号码',
                    applytime:'申请时间',
                    status:'2',
                    dealtime:'处理时间',
                    domain:'现有域名',
                    domainstatus:'域名使用状态',
                    startdomain:'原有域名'
                },
                {
                    ments: '用户ID',
                    userinfo: '用户昵称',
                    phonenumber:'手机号码',
                    applytime:'申请时间',
                    status:'2',
                    dealtime:'处理时间',
                    domain:'现有域名',
                    domainstatus:'域名使用状态',
                    startdomain:'原有域名'
                }, 
                {
                    ments: '用户ID',
                    userinfo: '用户昵称',
                    phonenumber:'手机号码',
                    applytime:'申请时间',
                    status:'2',
                    dealtime:'处理时间',
                    domain:'现有域名',
                    domainstatus:'域名使用状态',
                    startdomain:'原有域名'
            }]
        }
    }
}
</script>
<style lang="scss" scoped>
.sucess-search{
    margin-top: 20px;
    text-align: right;
    input{
        display: inline-block;
        height: 30px;
        line-height: 30px;
        padding: 0 10px;
    }
    input::-webkit-input-placeholder{
        color:#ccc;
    }
    input::-moz-placeholder{   /* Mozilla Firefox 19+ */
        color:#ccc;
    }
    input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
        color:#ccc;
    }
    input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
        color:#ccc;
    }
}
.sucess-main{
    margin-top: 20px;
}
</style>

