<template>
    <div class="wait">
        <div class="wait-search clearfix">
            日期：
            <el-date-picker
            v-model="time1"
            type="date"
            placeholder="开始时间">
            </el-date-picker>
            <el-date-picker
            v-model="time2"
            type="date"
            placeholder="结束时间">
            </el-date-picker>
            <input type="text" placeholder="请输入关键字筛选">
            <el-button type="primary" plain>查询</el-button>
        </div>
        <div class="wait-main">
            <el-table
            :data="tableData"
            stripe
            style="width: 100%">
                <el-table-column
                prop="ments"
                label="用户ID">
                </el-table-column>
                <el-table-column
                prop="userinfo"
                label="用户昵称">
                </el-table-column>
                <el-table-column
                prop="applytime"
                label="申请时间">
                </el-table-column>
                <el-table-column
                prop="status"
                label="状态">
                </el-table-column>
                <el-table-column
                prop="phonenumber"
                label="手机号码">
                </el-table-column>
                <el-table-column
                prop="source"
                label="来源">
                </el-table-column>
                <el-table-column
                prop="message"
                label="需要留言">
                </el-table-column>
                <el-table-column
                label="操作" class="opeate">
                 <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color" @click="wDeal">{{ scope.row.deal }}</span>
                    <span style="margin-left: 10px" class="show-color" @click="Ignore">{{ scope.row.ignore }}</span>
                </template>
                </el-table-column>
            </el-table>
        </div>
        <!-- 处理 -->
        <el-dialog title="增值服务" :visible.sync="WaitFlag">
        <el-row :gutter="20">
            <el-col :span="4"><div class="grid-content bg-purple">云播号</div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">800527</div></el-col>
        </el-row>
        <el-row :gutter="20">
            <el-col :span="4"><div class="grid-content bg-purple">增值服务</div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">服务类型</div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">服务结束时间</div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">服务升级（00表示永久）</div></el-col>
            <el-col :span="8" class="money"><div class="grid-content bg-purple">金额（元）</div></el-col>
        </el-row>
        <el-row :gutter="20">
            <el-col :span="4" class="widthout"><div class="grid-content bg-purple">.</div></el-col>
            <el-col :span="4" class="space"><div class="grid-content bg-purple"><span @click="setDeal" :class="showDealChoice ? 'sborder' : ''">授权管理<img src="@/components/images/pop_ic_selected.png" alt="404" v-if="showDealChoice"></span></div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">--</div></el-col>
            <el-col :span="4" class="month"><div class="grid-content bg-purple"><input type="number" v-model="month"> 个月</div></el-col>
            <el-col :span="4" class="gb"><div class="grid-content bg-purple"><input type="number" v-model="deal"> GB</div></el-col>
            <el-col :span="4" class="entermoney"><div class="grid-content bg-purple"><input type="text"></div></el-col>
        </el-row>
        <el-row :gutter="20">
            <el-col :span="4" class="widthout"><div class="grid-content bg-purple">.</div></el-col>
            <el-col :span="4" class="space"><div class="grid-content bg-purple"><span @click="setDeal" :class="showDealChoice ? 'sborder' : ''">品牌定制<img src="@/components/images/pop_ic_selected.png" alt="404" v-if="showDealChoice"></span></div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">--</div></el-col>
            <el-col :span="4" class="month"><div class="grid-content bg-purple"><input type="number" v-model="month"> 个月</div></el-col>
            <el-col :span="4" class="gb"><div class="grid-content bg-purple"><input type="number" v-model="deal"> GB</div></el-col>
            <el-col :span="4" class="entermoney"><div class="grid-content bg-purple"><input type="text"></div></el-col>
        </el-row>
         <el-row :gutter="20">
            <el-col :span="4" class="widthout"><div class="grid-content bg-purple">.</div></el-col>
            <el-col :span="4" class="space"><div class="grid-content bg-purple"><span @click="setDeal" :class="showDealChoice ? 'sborder' : ''">存储扩容<img src="@/components/images/pop_ic_selected.png" alt="404" v-if="showDealChoice"></span></div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">--</div></el-col>
            <el-col :span="4" class="month"><div class="grid-content bg-purple"><input type="number" v-model="month"> 个月</div></el-col>
            <el-col :span="4" class="gb"><div class="grid-content bg-purple"><input type="number" v-model="deal"> GB</div></el-col>
            <el-col :span="4" class="entermoney"><div class="grid-content bg-purple"><input type="text"></div></el-col>
        </el-row>
        <el-row :gutter="20">
            <el-col :span="4" class="widthout"><div class="grid-content bg-purple">.</div></el-col>
            <el-col :span="4" class="space"><div class="grid-content bg-purple"><span @click="setDeal" :class="showDealChoice ? 'sborder' : ''">微信支付<img src="@/components/images/pop_ic_selected.png" alt="404" v-if="showDealChoice"></span></div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">--</div></el-col>
            <el-col :span="4" class="month"><div class="grid-content bg-purple"><input type="number" v-model="month"> 个月</div></el-col>
            <el-col :span="4" class="gb"><div class="grid-content bg-purple"><input type="number" v-model="deal"> GB</div></el-col>
            <el-col :span="4" class="entermoney"><div class="grid-content bg-purple"><input type="text"></div></el-col>
        </el-row>
        <el-row :gutter="20">
            <el-col :span="4" class="widthout"><div class="grid-content bg-purple">.</div></el-col>
            <el-col :span="4" class="space"><div class="grid-content bg-purple"><span @click="setDeal" :class="showDealChoice ? 'sborder' : ''">企业域名<img src="@/components/images/pop_ic_selected.png" alt="404" v-if="showDealChoice"></span></div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">--</div></el-col>
            <el-col :span="4" class="month"><div class="grid-content bg-purple"><input type="number" v-model="month"> 个月</div></el-col>
            <el-col :span="4" class="gb"><div class="grid-content bg-purple"><input type="number" v-model="deal"> GB</div></el-col>
            <el-col :span="4" class="entermoney"><div class="grid-content bg-purple"><input type="text"></div></el-col>
        </el-row>
        <el-row :gutter="20">
            <el-col :span="4" class="pay-way"><div class="grid-content bg-purple"><span>支付方式</span></div></el-col>
            <el-col :span="4" class="balance"><div class="grid-content bg-purple"><span>余额支付<img src="@/components/images/pop_ic_selected.png" alt="404"></span></div></el-col>
        </el-row>
        <el-row :gutter="20">
            <el-col :span="4"><div class="grid-content bg-purple">支付总金额</div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">0</div></el-col>
        </el-row>
        <div slot="footer" class="dialog-footer">
            <el-button @click="WaitFlag = false">取 消</el-button>
            <el-button type="primary" @click="WaitFlag = false">确 定</el-button>
        </div>
        </el-dialog>
        <!-- 忽略 -->
        <el-dialog
        title="提示"
        :visible.sync="ignoreVisible"
        width="30%">
            <textarea id="ignoreTW" rows="10" placeholder="忽略原因"></textarea>
            <span slot="footer" class="dialog-footer">
                <el-button @click="ignoreVisible = false">取 消</el-button>
                <el-button type="primary" @click="ignoreVisible = false">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>
export default {
    data(){
        return {
            WaitFlag:false,
            showDealChoice:false,
            ignoreVisible:false,
            time1:'',
            time2:'',
            month:0,
            deal:1,
            tableData: [
                {
                    ments: '用户ID',
                    userinfo: '用户昵称',
                    applytime:'申请时间',
                    status:'2',
                    phonenumber:'手机号码',
                    source:'来源',
                    message:'需要留言',
                    deal:'处理',
                    ignore:'忽略'
                }, 
                {
                    ments: '用户ID',
                    userinfo: '用户昵称',
                    applytime:'申请时间',
                    status:'2',
                    phonenumber:'手机号码',
                    source:'来源',
                    message:'需要留言',
                    deal:'处理',
                    ignore:'忽略'
                },
                {
                    ments: '用户ID',
                    userinfo: '用户昵称',
                    applytime:'申请时间',
                    status:'2',
                    phonenumber:'手机号码',
                    source:'来源',
                    message:'需要留言',
                    deal:'处理',
                    ignore:'忽略'
                }, 
                {
                    ments: '用户ID',
                    userinfo: '用户昵称',
                    applytime:'申请时间',
                    status:'2',
                    phonenumber:'手机号码',
                    source:'来源',
                    message:'需要留言',
                    deal:'处理',
                    ignore:'忽略'
            }]
        }
    },
    methods:{
        wDeal(){
            this.WaitFlag = true;
        },
        setDeal(){
            this.showDealChoice = !this.showDealChoice;
        },
        Ignore(){
            this.ignoreVisible = true;
        }
    }
}
</script>
<style lang="scss" scoped>
.wait-search{
    margin-top: 20px;
    text-align: right;
    input{
        display: inline-block;
        height: 30px;
        line-height: 30px;
        padding: 0 10px;
    }
    input::-webkit-input-placeholder{
        color:#ccc;
    }
    input::-moz-placeholder{   /* Mozilla Firefox 19+ */
        color:#ccc;
    }
    input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
        color:#ccc;
    }
    input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
        color:#ccc;
    }
}
.wait-main{
    margin-top: 20px;
}
.cell{
    .show-color{
        color: #337ab7;
        cursor: pointer;
    }
}
.money{
    text-align: right;
}
.el-row{
    padding: 8px;
}
.space,.balance{
    div{
        span{
            border: 1px solid #c2c2c2;
            display: inline-block;
            width: 80px;
            height: 32px;
            line-height: 32px;
            text-align: center;
            position: relative;
            &.sborder {
                border-color: #1890ff;
            }
            img{
                position: absolute;
                right: 0;
                bottom: -1px;
            }
        }
    }
}
.month,.gb,.entermoney{
    input{
        border: 1px solid #c2c2c2;
        display: inline-block;
        width: 80px;
        height: 32px;
        line-height: 32px;
        text-align: center;
    }
}
.entermoney{
    text-align: right;
}
.pay-way{
    span{
        display: inline-block;
        height: 32px;
        line-height: 32px;
    }
}
.widthout{
    div{
        transform: scale(0.1);
    }
}
#ignoreTW {
    border: 1px solid #ddd;
    padding: 10px;
    width: 100%;
}
</style>

