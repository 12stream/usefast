<template>
    <div class="server">
        <div class="set">
            <h3>全局设置</h3>
            <el-row :gutter="20" class="set-content">
                <el-col :span="6"><div class="grid-content bg-purple">
                    计费模式：观看总时长
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple">
                    价格：0.05元/人/分钟
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple">
                    修改时间：2018-08-02 17:23:13
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple edit">
                    <i class="el-icon-edit-outline" @click="GlobalChange"></i>
                </div></el-col>
            </el-row>
        </div>
        <div class="record">
            <h3>修改记录</h3>
            <div class="record-show">
                <ul>
                    <li>
                        <p>2018-08-02 17:23:13</p>
                        <p>
                            <span class="disance">计费模式：观看总时长</span>
                            <span>价格：0.05元/人/分钟</span>
                        </p>
                    </li>
                    <li>
                        <p>2018-08-02 17:23:13</p>
                        <p>
                            <span class="disance">计费模式：观看总时长</span>
                            <span>价格：0.05元/人/分钟</span>
                        </p>
                    </li>
                    <li>
                        <p>2018-08-02 17:23:13</p>
                        <p>
                            <span class="disance">计费模式：观看总时长</span>
                            <span>价格：0.05元/人/分钟</span>
                        </p>
                    </li>
                    <li>
                        <p>2018-08-02 17:23:13</p>
                        <p>
                            <span class="disance">计费模式：观看总时长</span>
                            <span>价格：0.05元/人/分钟</span>
                        </p>
                    </li>
                    <li>
                        <p>2018-08-02 17:23:13</p>
                        <p>
                            <span class="disance">计费模式：观看总时长</span>
                            <span>价格：0.05元/人/分钟</span>
                        </p>
                    </li>
                    <li>
                        <p>2018-08-02 17:23:13</p>
                        <p>
                            <span class="disance">计费模式：观看总时长</span>
                            <span>价格：0.05元/人/分钟</span>
                        </p>
                    </li>
                    <li>
                        <p>2018-08-02 17:23:13</p>
                        <p>
                            <span class="disance">计费模式：观看总时长</span>
                            <span>价格：0.05元/人/分钟</span>
                        </p>
                    </li>
                    <li>
                        <p>2018-08-02 17:23:13</p>
                        <p>
                            <span class="disance">计费模式：观看总时长</span>
                            <span>价格：0.05元/人/分钟</span>
                        </p>
                    </li>
                    <li>
                        <p>2018-08-02 17:23:13</p>
                        <p>
                            <span class="disance">计费模式：观看总时长</span>
                            <span>价格：0.05元/人/分钟</span>
                        </p>
                    </li>
                    <li>
                        <p>2018-08-02 17:23:13</p>
                        <p>
                            <span class="disance">计费模式：观看总时长</span>
                            <span>价格：0.05元/人/分钟</span>
                        </p>
                    </li>
                    <li>
                        <p>2018-08-02 17:23:13</p>
                        <p>
                            <span class="disance">计费模式：观看总时长</span>
                            <span>价格：0.05元/人/分钟</span>
                        </p>
                    </li>
                </ul>
            </div>
        </div>
        <div class="user-set">
            <div class="title">
                <h3 class="clearfix">用户设置</h3>
                <el-button type="primary" class="add clearfix">新增用户计费模式</el-button>
            </div>
            <div class="user-set-content">
                <el-table
                :data="tableData"
                style="width: 100%">
                    <el-table-column
                    label="用户昵称"
                    width="180">
                    <template slot-scope="scope">
                        <span style="margin-left: 10px">{{ scope.row.username }}</span>
                    </template>
                    </el-table-column>
                    <el-table-column
                    label="用户ID"
                    width="180">
                    <template slot-scope="scope">
                        <span>{{ scope.row.ments}}</span>
                    </template>
                    </el-table-column>
                    <el-table-column
                    label="计费模式"
                    width="180">
                    <template slot-scope="scope">
                        <span>{{ scope.row.billingmode}}</span>
                    </template>
                    </el-table-column>
                    <el-table-column
                    label="价格"
                    width="180">
                    <template slot-scope="scope">
                        <span>{{ scope.row.price}}</span>
                    </template>
                    </el-table-column>
                    <el-table-column
                    label="开始时间"
                    width="180">
                    <template slot-scope="scope">
                        <span>{{ scope.row.startdate}}</span>
                    </template>
                    </el-table-column>
                     <el-table-column
                    label="结束时间"
                    width="180">
                    <template slot-scope="scope">
                        <span>{{ scope.row.enddate}}</span>
                    </template>
                    </el-table-column>
                    <el-table-column label="操作">
                    <template slot-scope="scope">
                        <el-button
                        size="mini"
                        @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
                        <el-button
                        size="mini"
                        type="danger"
                        @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                    </template>
                    </el-table-column>
                </el-table>
            </div>
        </div>
        <!-- 全局设置修改 -->
        <el-dialog title="修改直播服务费全局设置" :visible.sync="globalVisible">
            <div class="price">
                <span>价格：</span>
                <input type="text">
            </div>
        <div slot="footer" class="dialog-footer">
            <el-button @click="globalVisible = false">取 消</el-button>
            <el-button type="primary" @click="globalVisible = false">确 定</el-button>
        </div>
        </el-dialog>
        <!-- 用户设置 -->
        <el-dialog title="×修改用户直播服务费计费模式" :visible.sync="globalUserSetVisible">
            <div class="price">
                <span>　云播号：</span>
                <input type="text">
            </div>
            <div class="mode">
                <span>计费模式：</span>
                <el-select v-model="modevalue" placeholder="请选择">
                    <el-option
                    v-for="item in modeDate"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </div>
            <div class="price">
                <span>　　价格：</span>
                <input type="text">
            </div>
            <div class="time">
                <span>　　时间：</span>
                <el-date-picker
                v-model="time3"
                type="date"
                placeholder="开始时间">
                </el-date-picker>
                到
                <el-date-picker
                v-model="time4"
                type="date"
                placeholder="结束时间">
                </el-date-picker>
            </div>
        <div slot="footer" class="dialog-footer">
            <el-button @click="globalUserSetVisible = false">取 消</el-button>
            <el-button type="primary" @click="globalUserSetVisible = false">确 定</el-button>
        </div>
        </el-dialog>
    </div>
</template>
<script>
export default {
    data(){
        return {
            globalVisible:false,
            globalUserSetVisible:false,
            modeDate:[
                {
                    value: '选项1',
                    label: '观看总时长'
                }
            ],
            modevalue:'',
            time3:'',
            time4:'',
            tableData: [
                {
                    username:'用户昵称',
                    ments:'用户ID',
                    billingmode:'计费模式',
                    price:'价格',
                    startdate: '2018-08-02 17:24:44',
                    enddate:'2118-08-02 17:24:44'
                }, 
                {
                    username:'用户昵称',
                    ments:'用户ID',
                    billingmode:'计费模式',
                    price:'价格',
                    startdate: '2018-08-02 17:24:44',
                    enddate:'2118-08-02 17:24:44'
                }, 
                {
                    username:'用户昵称',
                    ments:'用户ID',
                    billingmode:'计费模式',
                    price:'价格',
                    startdate: '2018-08-02 17:24:44',
                    enddate:'2118-08-02 17:24:44'
                }, 
                {
                    username:'用户昵称',
                    ments:'用户ID',
                    billingmode:'计费模式',
                    price:'价格',
                    startdate: '2018-08-02 17:24:44',
                    enddate:'2118-08-02 17:24:44'
                }
            ]
        }
    },
    methods: {
      handleEdit(index, row) {
        this.globalUserSetVisible = true;
      },
      handleDelete(index, row) {
        console.log(index, row);
      },
      GlobalChange(){
          this.globalVisible = true;
      }
    }
}
</script>
<style lang="scss" scoped>
.set {
    border-bottom: 4px solid #ddd;
    background: #fff;
    .set-content{
        padding: 20px;
        border-top: 1px solid #ddd;
        border-bottom: 1px solid #ddd;
        .edit{
            text-align: right;
        }
    }
    h3 {
        padding: 20px;
        font-weight: 600;
        color: #555;
    }
}
.record{
    background: #fff;
    h3 {
        padding: 20px;
        font-weight: 600;
        color: #555;
        border-bottom: 1px solid #ddd;
    }
    .record-show{
        min-height: 80px;
        max-height: 520px;
        overflow: auto;
        ul{
            li{
                margin-left: 20px;
                padding: 20px 0;
                border-bottom: 1px solid #ddd;
                p{
                    font-size: 14px;
                    .disance{
                        margin-right: 96px;
                    }
                }
            }
        }
    }
}
.user-set{
    margin-top: 20px;
    background: #fff;
    padding: 20px 20px 10px;
    border-top: 3px solid #ddd;
    .title{
        height: 30px;
    }
    h3 {
        float: left;
    }
    .add{
        float: right;
    }
    .user-set-content{
        border-top: 3px solid #ddd;
        padding-top: 10px;
    }

}
.price{
    input{
        border: 1px solid #ddd;
        padding: 10px;
        width: 80%;
    }
}
.mode{
    margin: 20px 0;
}
.time{
    margin-top: 20px;
}
</style>

