<template>
    <div id="entrance_ticket_manage">
         <div class="ticket-search clearfix">
            日期：
            <el-date-picker
            v-model="time1"
            type="date"
            placeholder="开始时间">
            </el-date-picker>
            <el-date-picker
            v-model="time2"
            type="date"
            placeholder="结束时间">
            </el-date-picker>
            <input type="text" placeholder="请输入关键字筛选">
            <el-button type="primary" plain>查询</el-button>
        </div>
        <div class="ticket-main">
            <el-table
            :data="tableData"
            stripe
            style="width: 100%">
                <el-table-column
                prop="order"
                label="序号">
                </el-table-column>
                <el-table-column
                prop="livemessage"
                label="直播间信息">
                </el-table-column>
                <el-table-column
                prop="userinfo"
                label="用户信息">
                </el-table-column>
                <el-table-column
                prop="starttime"
                label="开始时间">
                </el-table-column>
                <el-table-column
                prop="seeroot"
                label="观看权限">
                </el-table-column>
                <el-table-column
                prop="status"
                label="状态">
                </el-table-column>
                <el-table-column
                prop="tickets"
                label="门票总数">
                </el-table-column>
                <el-table-column
                prop="remaining"
                label="剩余总数">
                </el-table-column>
                <el-table-column
                prop="usetotal"
                label="使用总数">
                </el-table-column>
                <el-table-column
                label="门票记录">
                    <template slot-scope="scope">
                        <span style="margin-left: 10px" class="show-color" @click="TicketView">{{ scope.row.ticketsrecord }}</span>
                    </template>
                </el-table-column>
                <el-table-column
                label="操作">
                    <template slot-scope="scope">
                        <span style="margin-left: 10px" class="show-color" @click="moreTicket">{{ scope.row.operate }}</span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <!-- 门票记录 -->
        <el-dialog title="门票记录" :visible.sync="ticketFlag">
            <ul class="ticket-tab">
                <li v-for="(item,i) in tabContents" :key="i" :class="currentTabsIndex == i ? 'tabs-item active' : 'tabs-item'" @click="selectTabs(i)">
                    {{item}}
                </li>
            </ul>
            <div class="ordinary" v-if="currentTabsIndex == 0">
                <div class="ticket-search">
                    <div class="left clearfix">每页显示  条记录</div>
                    <div class="right clearfix">
                        <input type="text" placeholder="请输入关键字筛选">
                        <el-button type="primary">查询</el-button>
                    </div>
                </div>
                <el-table :data="ticketData">
                    <el-table-column property="order" label="序号"></el-table-column>
                    <el-table-column property="ticketcode" label="门票码"></el-table-column>
                    <el-table-column property="status" label="状态"></el-table-column>
                    <el-table-column property="userid" label="云播号"></el-table-column>
                    <el-table-column property="username" label="用户名"></el-table-column>
                    <el-table-column property="money" label="金额（元）"></el-table-column>
                </el-table>
            </div>
            <div class="pay" v-if="currentTabsIndex == 1">
                <div class="ticket-search">
                    <div class="left clearfix">每页显示  条记录</div>
                    <div class="right clearfix">
                        <input type="text" placeholder="请输入关键字筛选">
                        <el-button type="primary">查询</el-button>
                    </div>
                </div>
                <el-table :data="ticketData">
                    <el-table-column property="order" label="序号"></el-table-column>
                    <el-table-column property="ticketcode" label="门票码"></el-table-column>
                    <el-table-column property="status" label="状态"></el-table-column>
                    <el-table-column property="userid" label="云播号"></el-table-column>
                    <el-table-column property="username" label="用户名"></el-table-column>
                    <el-table-column property="money" label="金额（元）"></el-table-column>
                </el-table>
            </div>
        </el-dialog>
        <!-- 注销余票 -->
        <el-dialog title="注销余票" :visible.sync="moreTicketVisible">
            <div class="price">
                <p>请导入已发放的门票，系统将会进行自动筛选</p>
                <p>若无门票数据，请先下载模板进行收集。<a href="@/../static/file/注销余票模板.xls">下载模板</a></p>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="moreTicketVisible = false">确 定</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script>
export default {
    data(){
        return {
            tabContents:[' 普通门票','付费门票'],
            currentTabsIndex:0,
            ticketFlag:false,
            time1:'',
            time2:'',
            ticketData:[],
            moreTicketVisible:false,
            tableData: [
                {
                    order: '序号',
                    livemessage: '直播间信息',
                    userinfo:'用户信息',
                    starttime:'开始时间',
                    seeroot:'观看权限',
                    status:'2',
                    tickets:'门票总数',
                    remaining:'剩余总数',
                    usetotal:'使用总数',
                    ticketsrecord:'查看',
                    operate:'注销余票'
                }, 
                {
                    order: '序号',
                    livemessage: '直播间信息',
                    userinfo:'用户信息',
                    starttime:'开始时间',
                    seeroot:'观看权限',
                    status:'2',
                    tickets:'门票总数',
                    remaining:'剩余总数',
                    usetotal:'使用总数',
                    ticketsrecord:'查看',
                    operate:'注销余票'
                },
                {
                    order: '序号',
                    livemessage: '直播间信息',
                    userinfo:'用户信息',
                    starttime:'开始时间',
                    seeroot:'观看权限',
                    status:'2',
                    tickets:'门票总数',
                    remaining:'剩余总数',
                    usetotal:'使用总数',
                    ticketsrecord:'查看',
                    operate:'注销余票'
                }, 
                {
                    order: '序号',
                    livemessage: '直播间信息',
                    userinfo:'用户信息',
                    starttime:'开始时间',
                    seeroot:'观看权限',
                    status:'2',
                    tickets:'门票总数',
                    remaining:'剩余总数',
                    usetotal:'使用总数',
                    ticketsrecord:'查看',
                    operate:'注销余票'
            }]
        }
    },
    methods:{
        selectTabs(val){
            this.currentTabsIndex = val;
        },
        TicketView(){
            this.ticketFlag = true;
        },
        moreTicket(){
            this.moreTicketVisible = true;
        }
    }
}
</script>
<style lang="scss" scoped>
.ticket-search{
    margin-top: 20px;
    text-align: right;
    input{
        display: inline-block;
        height: 30px;
        line-height: 30px;
        padding: 0 10px;
    }
    input::-webkit-input-placeholder{
        color:#ccc;
    }
    input::-moz-placeholder{   /* Mozilla Firefox 19+ */
        color:#ccc;
    }
    input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
        color:#ccc;
    }
    input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
        color:#ccc;
    }
}
.ticket-main{
    margin-top: 20px;
}
.cell{
    .show-color{
        color: #337ab7;
        cursor: pointer;
    }
}
.ticket-tab {
    border-bottom: 1px solid #ddd;
    .tabs-item{
        display: inline-block;
        color: #676a6c;
        padding: 10px 20px 10px 25px;
        &.active{
            color: #333;
            border: 1px solid #ddd;
            border-bottom: 0;
        }
    }
}
.ticket-search {
    height: 40px;
    margin-bottom: 20px;
    .left{
        float: left;
    }
    .right{
        float: right;
        input{
            border: 1px solid #ddd;
        }
    }
}
</style>

