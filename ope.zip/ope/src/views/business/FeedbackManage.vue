<template>
    <div id="feedback_manage">
        <el-table
        :data="tableData"
        stripe
        style="width: 100%">
            <el-table-column
            prop="order"
            label="序号">
            </el-table-column>
            <el-table-column
            prop="ments"
            label="用户ID">
            </el-table-column>
            <el-table-column
            prop="username"
            label="用户昵称">
            </el-table-column>
            <el-table-column
            prop="feedbacktime"
            label="反馈时间">
            </el-table-column>
            <el-table-column
            prop="contact"
            label="联系方式">
            </el-table-column>
            <el-table-column
            prop="feebbacksource"
            label="反馈来源">
            </el-table-column>
            <el-table-column
            prop="feedbackdetails"
            label="建议 / 反馈详情">
            </el-table-column>
        </el-table>
    </div>
</template>
<script>
export default {
    data(){
        return {
            tableData:[]
        }
    }
}
</script>
<style lang="scss" scoped>

</style>

