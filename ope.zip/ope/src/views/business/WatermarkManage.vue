<template>
    <div id="watermark_manage">
        <div class="tab">
            <div class="live-status clearfix" v-for="(item,i) in tabContents" :key="i">
                <div :class="currentTabsIndex == i ? 'tabs-item active' : 'tabs-item'" @click="selectTabs(i)">
                    {{item}}
                </div>
            </div>
        </div>
        <List v-show="currentTabsIndex == 0"></List>
        <Library v-show="currentTabsIndex == 1"></Library>
    </div>
</template>
<script>
import List from './components/watermark/List'
import Library from './components/watermark/Library'
export default {
    data(){
        return {
            tabContents:['牌照水印列表','水印库'],
            currentTabsIndex:0
        }
    },
    components:{List, Library},
    methods:{
        selectTabs(val){
            this.currentTabsIndex = val;
        }
    }
}
</script>
<style lang="scss" scoped>
.tab{
    border-bottom: 1px solid #ddd;
    height: 44px;
    line-height: 44px;
    .live-status{
        float: left;
        .tabs-item{
            color: #676a6c;
            padding: 0 20px;
            &.active{
                color: #333;
                border: 1px solid #ddd;
                border-bottom: 0;
            }
        }
    }
}
</style>

