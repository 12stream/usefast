<template>
    <div id="business_manage">
        <div class="tab">
            <ul>
                <li v-for="(item,i) in tabContents" :key="i" @click="selectTabs(i)" :class="currentFTabsIndex == i ? 'show' : ''">
                    {{item}}
                </li>
            </ul>
        </div>
        <Negotiation v-show="currentFTabsIndex == 0"></Negotiation>
        <DomainChange v-show="currentFTabsIndex == 1"></DomainChange>
    </div>
</template>
<script>
import Negotiation from './components/businessM/Negotiation'
import DomainChange from './components/businessM/DomainChange'
export default {
    data(){
        return {
            tabContents:['商务洽谈','域名变更'],
            currentFTabsIndex:0
        }
    },
    components:{Negotiation, DomainChange},
    methods:{
        selectTabs(val){
            this.currentFTabsIndex = val;
        }
    },
    mounted(){
       
    }
}
</script>
<style lang="scss" scoped>
.tab{
    ul{
        li{
            display: inline-block;
            margin: 0 20px 5px;
            padding-bottom: 9px;
            font-size: 16px;
            color: #1ab394;
            font-weight: bold;
            &.show{
                border-bottom: 2px solid #1ab394;
            }
        }
    }
}
</style>

