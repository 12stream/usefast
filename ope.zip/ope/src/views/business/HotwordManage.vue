<template>
    <div id="hotword_manage">
        <div class="hotword-search">
            <el-button type="primary" plain>新增热词</el-button>
        </div>
        <div class="hotword-main">
            <el-table
            :data="tableData"
            style="width: 100%">
                <el-table-column
                label="编号">
                <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.serial }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="热门词汇">
                <template slot-scope="scope">
                    <span>{{ scope.row.hotword}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="热门排序">
                <template slot-scope="scope">
                    <span>{{ scope.row.hotorder}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="创建时间">
                <template slot-scope="scope">
                    <span>{{ scope.row.createtime}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="修改时间">
                <template slot-scope="scope">
                    <span>{{ scope.row.changetime}}</span>
                </template>
                </el-table-column>
                <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button
                    size="mini"
                    @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
                    <el-button
                    size="mini"
                    type="danger"
                    @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                </template>
                </el-table-column>
            </el-table>
        </div>
        <!-- 编辑 -->
        <el-dialog title="编辑热词" :visible.sync="hotVisible">
            <div class="hotword">
                <span>　　热词：</span>
                <input type="text">
            </div>
            <div class="rank">
                <span>热门排名：</span>
                <input type="text">
            </div>
        <div slot="footer" class="dialog-footer">
            <el-button @click="hotVisible = false">取 消</el-button>
            <el-button type="primary" @click="hotVisible = false">确 定</el-button>
        </div>
        </el-dialog>
    </div>
</template>
<script>
export default {
    data(){
        return {
            hotVisible:false,
            tableData: [
                {
                    serial: '编号',
                    hotword: '热门词汇',
                    createtime:'创建时间',
                    changetime:'修改时间',
                    hotorder:'热门排序'
                }, 
                {
                    serial: '编号',
                    hotword: '热门词汇',
                    createtime:'创建时间',
                    changetime:'修改时间',
                    hotorder:'热门排序'
                },
                {
                    serial: '编号',
                    hotword: '热门词汇',
                    createtime:'创建时间',
                    changetime:'修改时间',
                    hotorder:'热门排序'
                }, 
                {
                    serial: '编号',
                    hotword: '热门词汇',
                    createtime:'创建时间',
                    changetime:'修改时间',
                    hotorder:'热门排序'
            }]
        }
    },
    methods: {
      handleEdit(index, row) {
          this.hotVisible = true;
        console.log(index, row);
      },
      handleDelete(index, row) {
        console.log(index, row);
      }
    }
}
</script>
<style lang="scss" scoped>
.hotword-search{
    padding-top: 20px;
    text-align: right;
    input{
        display: inline-block;
        height: 30px;
        line-height: 30px;
        padding: 0 10px;
    }
    input::-webkit-input-placeholder{
        color:#ccc;
    }
    input::-moz-placeholder{   /* Mozilla Firefox 19+ */
        color:#ccc;
    }
    input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
        color:#ccc;
    }
    input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
        color:#ccc;
    }
}
.hotword-main{
    margin-top: 20px;
}
.hotword,.rank{
    margin-top: 20px;
    span{
        margin-right: 20px;
    }
    input{
        border: 1px solid #ddd;
        padding: 10px;
        width: 80%;
    }
}
</style>

