<template>
    <div id="tipoff_manage">
        <div class="tipoff-search">
            <input type="text" placeholder="请输入ID或昵称">
            <el-button type="primary">查询</el-button>
        </div>
        <div class="tipoff-main">
            <el-table
            :data="tableData"
            style="width: 100%">
                <el-table-column
                prop="repeatId"
                label="举报人云播号">
                </el-table-column>
                <el-table-column
                prop="repeatName"
                label="举报人昵称">
                </el-table-column>
                <el-table-column
                prop="repeatTime"
                label="举报时间">
                </el-table-column>
                <el-table-column
                prop="repeatReson"
                label="举报原因">
                </el-table-column>
                <el-table-column
                prop="whistleblowersId"
                label="被举报人云播号">
                </el-table-column>
                <el-table-column
                prop="whistleblowersName"
                label="被举报人昵称">
                </el-table-column>
                <el-table-column
                prop="whistleblowersCome"
                label="举报来源">
                </el-table-column>
                <el-table-column
                label="预览">
                <template slot-scope="scope">
                    <span class="show-color" @click="check">{{ scope.row.preview}}</span>
                </template>
                </el-table-column>
            </el-table>
        </div>
        <!-- 查看 -->
         <el-dialog title="直播标题" :visible.sync="tipoLiveFlag">
            <el-table :data="tipoLiveData">
                <el-table-column property="videoId" label="录像ID"></el-table-column>
                <el-table-column property="videoName" label="录像名称"></el-table-column>
                <el-table-column property="createTime" label="生成时间"></el-table-column>
                <el-table-column label="操作">
                    <template slot-scope="scope">
                        <span class="show-color" @click="seeVideo">{{ scope.row.operate}}</span>
                    </template>
                </el-table-column>
            </el-table>
        </el-dialog>
    </div>
</template>
<script>
export default {
    data(){
        return {
            tipoLiveFlag:false,
            tipoLiveData:[],
            tableData: [
                {
                    repeatId:'举报人云播号',
                    repeatName:'举报人昵称',
                    repeatTime:'举报时间',
                    repeatReson:'举报原因',
                    whistleblowersId:'被举报人云播号',
                    whistleblowersName:'被举报人昵称',
                    whistleblowersCome:'举报来源',
                    preview:'查看'
                }, 
                {
                    repeatId:'举报人云播号',
                    repeatName:'举报人昵称',
                    repeatTime:'举报时间',
                    repeatReson:'举报原因',
                    whistleblowersId:'被举报人云播号',
                    whistleblowersName:'被举报人昵称',
                    whistleblowersCome:'举报来源',
                    preview:'查看'
                },
                {
                    repeatId:'举报人云播号',
                    repeatName:'举报人昵称',
                    repeatTime:'举报时间',
                    repeatReson:'举报原因',
                    whistleblowersId:'被举报人云播号',
                    whistleblowersName:'被举报人昵称',
                    whistleblowersCome:'举报来源',
                    preview:'查看'
                }, 
                {
                    repeatId:'举报人云播号',
                    repeatName:'举报人昵称',
                    repeatTime:'举报时间',
                    repeatReson:'举报原因',
                    whistleblowersId:'被举报人云播号',
                    whistleblowersName:'被举报人昵称',
                    whistleblowersCome:'举报来源',
                    preview:'查看'
            }]
        }
    },
    methods:{
        check(){
            this.tipoLiveFlag = true;
        },
        seeVideo(){
            
        }
    }
}
</script>
<style lang="scss" scoped>
.tipoff-search{
    margin-top: 20px;
    input{
        display: inline-block;
        height: 30px;
        line-height: 30px;
        padding: 0 10px;
    }
    input::-webkit-input-placeholder{
        color:#ccc;
    }
    input::-moz-placeholder{   /* Mozilla Firefox 19+ */
        color:#ccc;
    }
    input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
        color:#ccc;
    }
    input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
        color:#ccc;
    }
}
.tipoff-main{
    margin-top: 20px;
}
.cell{
    .show-color{
        color: #337ab7;
        cursor: pointer;
    }
}
</style>

