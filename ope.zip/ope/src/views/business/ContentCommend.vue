<template>
    <div id="content_commend">
         <div class="commend-search">
            <el-button type="primary" plain>新增推荐</el-button>
        </div>
        <div class="commend-main">
            <el-table
            :data="tableData"
            style="width: 100%">
                <el-table-column
                label="序号"
                width="180">
                <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.order }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="直播间ID"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.liveid}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="用户昵称"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.username}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="用户ID"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.ments}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="直播封面"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.liveimg}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="直播标题"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.livetitle}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="开始时间"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.starttime}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="当前状态"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.curstatus}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="排名"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.rand}}</span>
                </template>
                </el-table-column>
                <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button
                    size="mini"
                    @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
                    <el-button
                    size="mini"
                    type="danger"
                    @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                </template>
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
             tableData: [
                {
                    order: '序号',
                    liveid: '直播间ID',
                    username:'用户昵称',
                    ments:'用户ID',
                    liveimg:'直播封面',
                    livetitle:'直播标题',
                    starttime:'开始时间',
                    curstatus:'当前状态',
                    rand:'排名'
                }, 
                {
                    order: '序号',
                    liveid: '直播间ID',
                    username:'用户昵称',
                    ments:'用户ID',
                    liveimg:'直播封面',
                    livetitle:'直播标题',
                    starttime:'开始时间',
                    curstatus:'当前状态',
                    rand:'排名'
                },
                {
                    order: '序号',
                    liveid: '直播间ID',
                    username:'用户昵称',
                    ments:'用户ID',
                    liveimg:'直播封面',
                    livetitle:'直播标题',
                    starttime:'开始时间',
                    curstatus:'当前状态',
                    rand:'排名'
                }, 
                {
                    order: '序号',
                    liveid: '直播间ID',
                    username:'用户昵称',
                    ments:'用户ID',
                    liveimg:'直播封面',
                    livetitle:'直播标题',
                    starttime:'开始时间',
                    curstatus:'当前状态',
                    rand:'排名'
            }]
        }
    },
    methods: {
      handleEdit(index, row) {
        console.log(index, row);
      },
      handleDelete(index, row) {
        console.log(index, row);
      }
    }
}
</script>
<style lang="scss" scoped>
.commend-search{
    padding-top: 20px;
    text-align: right;
    input{
        display: inline-block;
        height: 30px;
        line-height: 30px;
        padding: 0 10px;
    }
    input::-webkit-input-placeholder{
        color:#ccc;
    }
    input::-moz-placeholder{   /* Mozilla Firefox 19+ */
        color:#ccc;
    }
    input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
        color:#ccc;
    }
    input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
        color:#ccc;
    }
}
.commend-main{
    margin-top: 20px;
}
</style>

