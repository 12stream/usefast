<template>
    <div id="hot_anchor">
         <div class="anchor-search">
            <el-button type="primary" plain>新增热词</el-button>
        </div>
        <div class="anchor-main">
            <el-table
            :data="tableData"
            style="width: 100%">
                <el-table-column
                label="编号"
                width="180">
                <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.serial }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="用户头像"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.userimg}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="用户昵称"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.username}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="用户ID"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.ments}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="粉丝量"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.fans}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="关注量"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.watch}}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="关注量"
                width="180">
                <template slot-scope="scope">
                    <span>{{ scope.row.watch}}</span>
                </template>
                </el-table-column>
                <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button
                    size="mini"
                    @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
                    <el-button
                    size="mini"
                    type="danger"
                    @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                </template>
                </el-table-column>
            </el-table>
        </div>
        <!-- 编辑 -->
        <el-dialog title="编辑默认关注" :visible.sync="anchorVisible">
            <div class="way">
                <span>　用户id</span>
                <input type="text">
            </div>
            <div class="rank">
                <span>热门排名</span>
                <input type="text">
            </div>
            <div class="fans">
                <span>　粉丝量</span>
                <input type="text">
            </div>
            <div class="focus">
                <span>　关注量</span>
                <input type="text">
            </div>
        <div slot="footer" class="dialog-footer">
            <el-button @click="anchorVisible = false">取 消</el-button>
            <el-button type="primary" @click="anchorVisible = false">确 定</el-button>
        </div>
        </el-dialog>
    </div>
</template>
<script>
export default {
    data(){
        return {
            anchorVisible:false,
            tableData: [
                {
                    serial: '编号',
                    userimg: '用户头像',
                    username:'用户昵称',
                    ments:'用户ID',
                    fans:'粉丝量',
                    watch:'关注量'
                }, 
                {
                    serial: '编号',
                    userimg: '用户头像',
                    username:'用户昵称',
                    ments:'用户ID',
                    fans:'粉丝量',
                    watch:'关注量'
                },
                {
                    serial: '编号',
                    userimg: '用户头像',
                    username:'用户昵称',
                    ments:'用户ID',
                    fans:'粉丝量',
                    watch:'关注量'
                }, 
                {
                    serial: '编号',
                    userimg: '用户头像',
                    username:'用户昵称',
                    ments:'用户ID',
                    fans:'粉丝量',
                    watch:'关注量'
            }]
        }
    },
    methods: {
      handleEdit(index, row) {
          this.anchorVisible = true;
        console.log(index, row);
      },
      handleDelete(index, row) {
        console.log(index, row);
      }
    }
}
</script>
<style lang="scss" scoped>
.anchor-search{
    padding-top: 20px;
    text-align: right;
    input{
        display: inline-block;
        height: 30px;
        line-height: 30px;
        padding: 0 10px;
    }
    input::-webkit-input-placeholder{
        color:#ccc;
    }
    input::-moz-placeholder{   /* Mozilla Firefox 19+ */
        color:#ccc;
    }
    input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
        color:#ccc;
    }
    input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
        color:#ccc;
    }
}
.anchor-main{
    margin-top: 20px;
}
.way,.rank,.fans,.focus{
    margin-top: 20px;
    span{
        margin-right: 20px;
    }
    input{
        border: 1px solid #ddd;
        padding: 10px;
        width: 80%;
    }
}
</style>

