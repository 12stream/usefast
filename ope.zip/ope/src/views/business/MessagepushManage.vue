<template>
    <div id="messagepush_manage">
        <div class="push-search">
           <el-button type="primary">新建推送</el-button>
            <input type="text" placeholder="请输入推送标题">
            <el-button type="primary">查询</el-button>
        </div>
        <div class="push-main">
            <el-table
            :data="tableData"
            stripe
            style="width: 100%">
                <el-table-column
                prop="order"
                label="序号">
                </el-table-column>
                <el-table-column
                prop="pushtime"
                label="推送时间">
                </el-table-column>
                <el-table-column
                prop="platform"
                label="平台">
                </el-table-column>
                <el-table-column
                prop="pushtype"
                label="推送类型">
                </el-table-column>
                <el-table-column
                prop="pushtitle"
                label="推送标题">
                </el-table-column>
                <el-table-column
                prop="pushcontent"
                label="推送内容">
                </el-table-column>
                <el-table-column
                prop="shifotest"
                label="是否测试">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            tableData: [
                {
                    order:'序号',
                    pushtime:'推送时间',
                    platform:'平台',
                    pushtype:'推送类型',
                    pushtitle:'推送标题',
                    pushcontent:'推送内容',
                    shifotest:'是否测试'
                }, 
                {
                    order:'序号',
                    pushtime:'推送时间',
                    platform:'平台',
                    pushtype:'推送类型',
                    pushtitle:'推送标题',
                    pushcontent:'推送内容',
                    shifotest:'是否测试'
                },
                {
                   order:'序号',
                    pushtime:'推送时间',
                    platform:'平台',
                    pushtype:'推送类型',
                    pushtitle:'推送标题',
                    pushcontent:'推送内容',
                    shifotest:'是否测试'
                }, 
                {
                    order:'序号',
                    pushtime:'推送时间',
                    platform:'平台',
                    pushtype:'推送类型',
                    pushtitle:'推送标题',
                    pushcontent:'推送内容',
                    shifotest:'是否测试'
            }]
        }
    }
}
</script>
<style lang="scss" scoped>
.push-search{
    margin-top: 20px;
    input{
        display: inline-block;
        height: 30px;
        line-height: 30px;
        padding: 0 10px;
    }
    input::-webkit-input-placeholder{
        color:#ccc;
    }
    input::-moz-placeholder{   /* Mozilla Firefox 19+ */
        color:#ccc;
    }
    input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
        color:#ccc;
    }
    input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
        color:#ccc;
    }
}
.push-main{
    margin-top: 20px;
}
</style>

