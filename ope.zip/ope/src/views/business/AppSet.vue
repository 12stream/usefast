<template>
    <div id="app_set">
        <ul>
            <li>科技蓝</li>
            <li>新年红</li>
        </ul>
    </div>
</template>
<script>
export default {
    data(){
        return {

        }
    }
}
</script>
<style lang="scss" scoped>
ul{
    li{
        display: inline-block;
        width: 210px;
        height: 210px;
        padding: 1em;
        -webkit-transition: -webkit-transform .15s linear;
        text-decoration: none;
        color: #000;
        background: #ffc;
        box-shadow: 5px 5px 7px rgba(33,33,33,.7);
        margin: 30px;
    }
    li:nth-of-type(1){
        transform: rotate(-6deg);
    }
    li:nth-of-type(2){
        transform: rotate(3deg);
    }
    li:hover{
        transform: rotate(0deg) scale(1.1);
    }
}
</style>

