<template>
    <div id="live">
        <div class="tab">
            <div class="live-status clearfix" v-for="(item,i) in tabContents" :key="i">
                <div :class="currentTabsIndex == i ? 'tabs-item active' : 'tabs-item'" @click="selectTabs(i)">
                    {{item}}
                </div>
            </div>
        </div>
        <Live v-show="currentTabsIndex == 0"></Live>
        <Playback v-show="currentTabsIndex == 1"></Playback>
        <Trailer v-show="currentTabsIndex == 2"></Trailer>
        <Banned v-show="currentTabsIndex == 3"></Banned>
        <Overdue v-show="currentTabsIndex == 4"></Overdue>
    </div>
</template>
<script>
import Live from './components/Live'
import Playback from './components/Playback'
import Trailer from './components/Trailer'
import Banned from './components/Banned'
import Overdue from './components/Overdue'
export default {
    data(){
        return {
            tabContents:['直播中','回放','直播预告','封禁直播','过期'],
            currentTabsIndex:0,
        }
    },
    components:{Live, Playback, Trailer, Banned, Overdue},
    methods:{
        selectTabs(val){
            this.currentTabsIndex = val;
        }
    }
}
</script>
<style lang="scss" scoped>
.tab{
    border-bottom: 1px solid #ddd;
    height: 44px;
    line-height: 44px;
    .live-status{
        float: left;
        .tabs-item{
            color: #676a6c;
            padding: 0 20px;
            &.active{
                color: #333;
                border: 1px solid #ddd;
                border-bottom: 0;
            }
        }
    }
}
</style>

