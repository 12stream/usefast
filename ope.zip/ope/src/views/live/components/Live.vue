<template>
    <div class="live">
        <div class="live-search">
            排序：
            <el-select v-model="value" placeholder="请选择">
                <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value">
                </el-option>
            </el-select>
            <div class="word">
                <input type="text" placeholder="请输入关键字筛选">
                <el-button type="primary" plain>查询</el-button>
            </div>
        </div>
        <div class="live-main">
            <el-table
            :data="tableData"
            stripe
            style="width: 100%">
                <el-table-column
                prop="id"
                label="直播间ID"
                >
                </el-table-column>
                <el-table-column
                prop="title"
                label="直播标题"
                >
                </el-table-column>
                <el-table-column
                prop="livenumber"
                label="在线人数">
                </el-table-column>
                <el-table-column
                label="直播预览">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color">{{ scope.row.livepreview }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="回放预览">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color" @click="watchPlayBack">{{ scope.row.againpreview }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="举报人数">
                 <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color" @click="repeatL">{{ scope.row.torepeat }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="违规处理">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color">{{ scope.row.violations }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="聊天室管理">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color" @click="ChatM">{{ scope.row.chat }}</span>
                </template>
                </el-table-column>
                <el-table-column
                prop="seeroot"
                label="观看权限">
                </el-table-column>
                <el-table-column
                prop="ments"
                label="用户ID">
                </el-table-column>
                <el-table-column
                prop="name"
                label="用户昵称">
                </el-table-column>
                <el-table-column
                prop="cover"
                label="直播封面">
                </el-table-column>
                <el-table-column
                prop="startTime"
                label="开始时间">
                </el-table-column>
                <el-table-column
                label="内容介绍">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color" @click="contentL">{{ scope.row.content }}</span>
                </template>
                </el-table-column>
                <el-table-column
                prop="seeNumber"
                label="观看人次">
                </el-table-column>
            </el-table>
        </div>
        <!-- 回放预览 -->
        <el-dialog title="举报详情" :visible.sync="playbackVisible" class="">
            <el-table :data="videoData" class="video-playback">
                <el-table-column property="videoId" label="序号" width="150"></el-table-column>
                <el-table-column property="videoName" label="举报人用户ID" width="200"></el-table-column>
                <el-table-column property="generateTime" label="举报人昵称"></el-table-column>
                <el-table-column
                label="操作">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color" @click="ChatInteractive">{{ scope.row.chatManage }}</span>
                    <span style="margin-left: 10px" class="show-color" @click="seeVideo">{{ scope.row.preview }}</span>
                    <span style="margin-left: 10px" class="show-color">{{ scope.row.delect }}</span>
                </template>
                </el-table-column>
            </el-table>
        </el-dialog>
         <!-- 举报人数 -->
       <el-dialog title="举报人数" :visible.sync="repeatFlag">
            <el-table :data="repeatData">
                <el-table-column property="order" label="排序" width="150"></el-table-column>
                <el-table-column property="whistleblowersuserid" label="举报人用户ID" width="200"></el-table-column>
                <el-table-column property="whistleblowersname" label="举报人昵称"></el-table-column>
                <el-table-column property="repeattime" label="举报时间"></el-table-column>
                <el-table-column property="repeatreason" label="举报原因"></el-table-column>
            </el-table>
            <div slot="footer" class="dialog-footer">
                <el-button @click="repeatFlag = false">取 消</el-button>
            </div>
        </el-dialog>
         <!-- 聊天室管理 -->
         <el-dialog title="聊天互动" :visible.sync="chatMFlag">
            <div class="bannedw">全员禁言：
                <el-select v-model="bannedvalue" placeholder="请选择">
                    <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button @click="chatMFlag = false">取 消</el-button>
            </div>
        </el-dialog>
         <!-- 内容介绍 -->
        <el-dialog title="内容详情" :visible.sync="contentFlag">
            <el-table :data="contentData">
                <el-table-column property="title" label="标题"></el-table-column>
                <el-table-column property="img" label="图片"></el-table-column>
            </el-table>
            <div slot="footer" class="dialog-footer">
                <el-button @click="contentFlag = false">取 消</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script>
export default {
    data(){
        return {
            playbackVisible:false,
            repeatFlag:false,
            chatMFlag:false,
            bannedvalue:'',
            contentFlag:false,
            options: [{
                value: '选项1',
                label: '是'
            }, {
                value: '选项2',
                label: '否'
            }],
            bannedvalue:'否',
            repeatData:[],
            contentData:[],
            options: [
                {
                    value: '选项1',
                    label: '开始时间'
                }, 
                {
                    value: '选项2',
                    label: '举报人数'
                },
                {
                    value: '选项3',
                    label: '在线人数'
                }
            ],
            value:'',
            videoData:[],
            tableData: [
                {
                    id: '169981101425559908',
                    title: '测试直播2',
                    livenumber: '21',
                    livepreview:'预览',
                    againpreview:'预览',
                    torepeat:'0',
                    violations:'封禁',
                    chat:'查看',
                    seeroot:'免费',
                    ments:'21',
                    name:'用户昵称',
                    cover:'直播封面',
                    startTime:'开始时间',
                    content:'内容介绍',
                    seeNumber:'观看人次'
                }, 
                {
                    id: '169981101425561031',
                    title: '自定义视频',
                    livenumber: '343',
                    livepreview:'预览',
                    againpreview:'预览',
                    torepeat:'0',
                    violations:'封禁',
                    chat:'查看',
                    seeroot:'门票',
                    ments:'22',
                    name:'用户昵称',
                    cover:'直播封面',
                    startTime:'开始时间',
                    content:'内容介绍',
                    seeNumber:'观看人次'
                },
                {
                    id: '169981101425560943',
                    title: '免费直播',
                    livenumber: '123',
                    livepreview:'预览',
                    againpreview:'预览',
                    torepeat:'0',
                    violations:'封禁',
                    chat:'查看',
                    seeroot:'付费',
                    ments:'23',
                    name:'用户昵称',
                    cover:'直播封面',
                    startTime:'开始时间',
                    content:'内容介绍',
                    seeNumber:'观看人次'
                }, 
                {
                    id: '169981101425560888',
                    title: '门票直播',
                    livenumber: '866',
                    livepreview:'预览',
                    againpreview:'预览',
                    torepeat:'0',
                    violations:'封禁',
                    chat:'查看',
                    seeroot:'免费',
                    ments:'25',
                    name:'用户昵称',
                    cover:'直播封面',
                    startTime:'开始时间',
                    content:'内容介绍',
                    seeNumber:'观看人次'
            }]
        }
    },
    methods:{
        watchPlayBack(){
            this.playbackVisible = true;
        },
        repeatL(){
            this.repeatFlag = true;
        },
         ChatM(){
            this.chatMFlag = true;
        },
        contentL(){
            this.contentFlag = true;
        }
    }
}
</script>
<style lang="scss" scoped>
.live{
    .el-table--scrollable-x::-webkit-scrollbar{
        display: none !important;
    }
    .live-search{
        text-align: right;
        margin: 20px 0;
        .word{
            display: inline-block;
            input{
                display: inline-block;
                height: 30px;
                line-height: 30px;
                padding: 0 10px;
            }
            input::-webkit-input-placeholder{
                color:#ccc;
            }
            input::-moz-placeholder{   /* Mozilla Firefox 19+ */
                color:#ccc;
            }
            input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
                color:#ccc;
            }
            input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
                color:#ccc;
            }
        }
    }
}
.live-main{
    .show-color{
        color: #337ab7;
        cursor: pointer;
    }
}
.bannedw{
    display: inline-block;
    .el-select{
        width: 100px;
    }
}
</style>


