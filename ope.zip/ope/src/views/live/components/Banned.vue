<template>
    <div class="banned">
        <div class="banned-search clearfix">
            <div class="delet clearfix">
                <el-button type="primary">批量删除</el-button>
            </div>
            <div class="word clearfix">
                排序：
                <el-select v-model="value" placeholder="请选择">
                    <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
                <input type="text" placeholder="请输入关键字筛选">
                <el-button type="primary" plain>查询</el-button>
            </div>
        </div>
        <div class="banned-main">
            <el-table
            :data="tableData"
            stripe
            style="width: 100%">
            <el-table-column
                type="selection"
                >
                </el-table-column>
                <el-table-column
                prop="id"
                label="直播间ID"
                >
                </el-table-column>
                <el-table-column
                prop="title"
                label="直播标题"
                >
                </el-table-column>
                <el-table-column
                label="回放预览">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color" @click="watchBanned">{{ scope.row.livepreview }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="举报人数">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color" @click="repeatB">{{ scope.row.torepeat }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="违规处理">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color">{{ scope.row.violations }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="聊天室管理">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color" @click="ChatB">{{ scope.row.chat }}</span>
                </template>
                </el-table-column>
                <el-table-column
                prop="seeroot"
                label="观看权限">
                </el-table-column>
                <el-table-column
                prop="ments"
                label="用户ID">
                </el-table-column>
                <el-table-column
                prop="name"
                label="用户昵称">
                </el-table-column>
                <el-table-column
                prop="cover"
                label="直播封面">
                </el-table-column>
                <el-table-column
                prop="startTime"
                label="开始时间">
                </el-table-column>
                <el-table-column
                label="内容介绍">
                    <template slot-scope="scope">
                        <span style="margin-left: 10px" class="show-color" @click="contentB">{{ scope.row.content }}</span>
                    </template>
                </el-table-column>
                <el-table-column
                prop="seeNumber"
                label="观看人次">
                </el-table-column>
                <el-table-column
                prop="seeTime"
                label="观看时长">
                </el-table-column>
                <el-table-column
                prop="livepreview"
                label="付费观看收入(梦豆)">
                </el-table-column>
                <el-table-column
                label="操作">
                    <template slot-scope="scope">
                        <span style="margin-left: 10px" class="show-color">{{ scope.row.opeate }}</span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <!-- 视频预览 -->
        <div class="video-mask" v-if="bannedVideoVisible"></div>
        <div id="video-play"></div>
        <div id="video-title" v-show="vFlag">
            <h3>来一场说走就走的旅行</h3>
            <span @click="hideVideo">x</span>
        </div>
        <!-- 回放预览 -->
        <el-dialog title="来一场说开就开的直播" :visible.sync="bannedVisible" class="">
            <el-table :data="videoData" class="video-banned">
                <el-table-column property="videoId" label="序号" width="150"></el-table-column>
                <el-table-column property="videoName" label="举报人用户ID" width="200"></el-table-column>
                <el-table-column property="generateTime" label="举报人昵称"></el-table-column>
                <el-table-column
                label="操作">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color" @click="bannedP">{{ scope.row.preview }}</span>
                    <span style="margin-left: 10px" class="show-color">{{ scope.row.delect }}</span>
                </template>
                </el-table-column>
            </el-table>
        </el-dialog>
         <!-- 举报人数 -->
       <el-dialog title="举报人数" :visible.sync="repeatFlag">
            <el-table :data="repeatData">
                <el-table-column property="order" label="排序" width="150"></el-table-column>
                <el-table-column property="whistleblowersuserid" label="举报人用户ID" width="200"></el-table-column>
                <el-table-column property="whistleblowersname" label="举报人昵称"></el-table-column>
                <el-table-column property="repeattime" label="举报时间"></el-table-column>
                <el-table-column property="repeatreason" label="举报原因"></el-table-column>
            </el-table>
            <div slot="footer" class="dialog-footer">
                <el-button @click="repeatFlag = false">取 消</el-button>
            </div>
        </el-dialog>
        <!-- 聊天室管理 -->
         <el-dialog title="聊天互动" :visible.sync="chatMFlag">
            <div class="bannedw">全员禁言：
                <el-select v-model="bannedvalue" placeholder="请选择">
                    <el-option
                    v-for="item in banD"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button @click="chatMFlag = false">取 消</el-button>
            </div>
        </el-dialog>
        <!-- 内容介绍 -->
        <el-dialog title="内容详情" :visible.sync="contentFlag">
            <el-table :data="contentData">
                <el-table-column property="title" label="标题"></el-table-column>
                <el-table-column property="img" label="图片"></el-table-column>
            </el-table>
            <div slot="footer" class="dialog-footer">
                <el-button @click="contentFlag = false">取 消</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script>
export default {
    data(){
        return {
            bannedVisible:false,
            bannedVideoVisible:false,
            vFlag:false,
            index:1,
            repeatFlag:false,
            chatMFlag:false,
            contentFlag:false,
            options: [
                {
                    value: '选项1',
                    label: '开始时间'
                }, 
                {
                    value: '选项2',
                    label: '举报人数'
                }
            ],
            value:'',
            banD:[
                {
                    value: '选项1',
                    label: '是'
                },
                {
                    value: '选项2',
                    label: '否'
                }
            ],
            bannedvalue:'否',
            videoData:[
                {
                    videoId: '录像ID',
                    videoName: '录像名称',
                    generateTime: '	生成时间',
                    preview:'预览',
                    delect:'删除'
                }, 
                {
                    videoId: '录像ID',
                    videoName: '录像名称',
                    generateTime: '	生成时间',
                    preview:'预览',
                    delect:'删除'
                }, 
                {
                    videoId: '录像ID',
                    videoName: '录像名称',
                    generateTime: '	生成时间',
                    preview:'预览',
                    delect:'删除'
                }, 
                {
                    videoId: '录像ID',
                    videoName: '录像名称',
                    generateTime: '	生成时间',
                    preview:'预览',
                    delect:'删除'
                }
            ],
            contentData: [
                {
                    title: '标题',
                    img: '图片'
                }, 
                {
                    title: '标题',
                    img: '图片'
                }
            ],
            repeatData:[],
            tableData: [
                {
                    id: '169981101425559908',
                    title: '测试直播2',
                    torepeat:'0',
                    violations:'封禁',
                    chat:'查看',
                    seeroot:'免费',
                    ments:'21',
                    name:'用户昵称',
                    cover:'直播封面',
                    startTime:'开始时间',
                    content:'内容介绍',
                    seeNumber:'观看人次',
                    seeTime: '21',
                    livepreview:'预览',
                    opeate:'删除'
                }, 
                {
                    id: '169981101425561031',
                    title: '自定义视频',
                    torepeat:'0',
                    violations:'封禁',
                    chat:'查看',
                    seeroot:'门票',
                    ments:'22',
                    name:'用户昵称',
                    cover:'直播封面',
                    startTime:'开始时间',
                    content:'内容介绍',
                    seeNumber:'观看人次',
                    seeTime: '21',
                    livepreview:'预览',
                    opeate:'删除'
                },
                {
                    id: '169981101425560943',
                    title: '免费直播',
                    torepeat:'0',
                    violations:'封禁',
                    chat:'查看',
                    seeroot:'付费',
                    ments:'23',
                    name:'用户昵称',
                    cover:'直播封面',
                    startTime:'开始时间',
                    content:'内容介绍',
                    seeNumber:'观看人次',
                    seeTime: '21',
                    livepreview:'预览',
                    opeate:'删除'
                }, 
                {
                    id: '169981101425560888',
                    title: '门票直播',
                    torepeat:'0',
                    violations:'封禁',
                    chat:'查看',
                    seeroot:'免费',
                    ments:'25',
                    name:'用户昵称',
                    cover:'直播封面',
                    startTime:'开始时间',
                    content:'内容介绍',
                    seeNumber:'观看人次',
                    seeTime: '21',
                    livepreview:'预览',
                    opeate:'删除'
            }]
        }
    },
    methods:{
        watchBanned(){
            this.bannedVisible = true;
        },
        bannedP(){
            this.bannedVideoVisible = true;
            this.$nextTick(()=>{
                if($("#video-play")){
                    this.vFlag = true;
                    $("#video-play").prepend($("#video-title"));
                    $('#video-play').show();
                }
            })
            if(this.index == 1){
                this.index++;
                var flashvars = {

                    f:'http://movie.ks.js.cn/flv/other/1_0.mp4',//视频的路径

                    p: 1,//视频默认 0是暂停，1是播放，2是不加载视频

                    c: '0',//是否读取文本配置,0不是，1是

                    e: 8,//视频结束后的动作，0是调用js函数，1是循环播放，2是暂停播放并且不调用广告，3是调用视频推荐列表的插件，4是清除视频流并调用js功能和1差不多，5是暂停播放并且调用暂停广告

                    v: '80',//默认音量，0-100之间,

                    // wh: '16:9',//宽高比，可以自己定义视频的宽高或宽高比如：wh:'4:3',或wh:'1080:720' '1376','756'

                    lv: '1',//是否是直播流，=1则锁定进度栏

                };
                var params = {
                    "bgcolor": "#fff",
                    "wmode": "transparent",
                    "allowFullScreen": true,
                    "allowScriptAccess": "always"
                };
                CKobject.embedSWF("@/../static/ckplayer/ckplayer.swf", "video-play", "ckplayer_a1", "1000", "500", flashvars, params);
            }
        },
        hideVideo(){
            this.vFlag = false;
            this.bannedVideoVisible = false;
            $('#video-play').hide();
        },
        repeatB(){
            this.repeatFlag = true;
        },
        ChatB(){
            this.chatMFlag = true;
        },
        contentB(){
            this.contentFlag = true;
        }
    }
}
</script>
<style lang="scss" scoped>
.banned-search{
    margin: 20px 0;
    .delet{
        float: left;
    }
    .word{
        float: right;
        input{
            display: inline-block;
            height: 30px;
            line-height: 30px;
            padding: 0 10px;
        }
        input::-webkit-input-placeholder{
            color:#ccc;
        }
        input::-moz-placeholder{   /* Mozilla Firefox 19+ */
            color:#ccc;
        }
        input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
            color:#ccc;
        }
        input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
            color:#ccc;
        }
    }
}
.banned-main,.video-banned{
    .show-color{
        color: #337ab7;
        cursor: pointer;
    }
}
#video-play{
    position:fixed;
    left: 50%;
    top: 100px;
    margin-left: -500px;
    z-index: 2006;
    #video-title{
       background: #fff;
       position: relative;
       padding: 15px;
       h3{
           display: inline-block;
       }
       span{
           position: absolute;
           right: 16px;
           top: 10px;
           font-size: 21px;
       }
    }
}
.video-mask{
    position: fixed;
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    z-index: 2002;
    background: #000;
    opacity: 0.4;
}
.bannedw{
    display: inline-block;
    .el-select{
        width: 100px;
    }
}
</style>


