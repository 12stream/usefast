<template>
    <div class="trailer">
        <div class="trailer-search clearfix">
            <div class="delet clearfix">
                <el-button type="primary">批量删除</el-button>
            </div>
            <div class="word clearfix">
                <input type="text" placeholder="请输入关键字筛选">
                <el-button type="primary" plain>查询</el-button>
            </div>
        </div>
        <div class="trailer-main">
            <el-table
            :data="tableData"
            stripe
            style="width: 100%">
            <el-table-column
                type="selection">
                </el-table-column>
                <el-table-column
                prop="id"
                label="直播间ID">
                </el-table-column>
                <el-table-column
                prop="cover"
                label="直播封面">
                </el-table-column>
                <el-table-column
                prop="title"
                label="直播标题">
                </el-table-column>
                <el-table-column
                label="回放预览">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color" @click="playBackP">{{ scope.row.againpreview }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="内容介绍">
                 <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color" @click="contentA">{{ scope.row.content }}</span>
                </template>
                </el-table-column>
                <el-table-column
                prop="startTime"
                label="开始时间">
                </el-table-column>
                <el-table-column
                label="举报人数">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color" @click="repeatT">{{ scope.row.torepeat }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="违规处理">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color">{{ scope.row.violations }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="聊天室管理">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color" @click="ChatM">{{ scope.row.chat }}</span>
                </template>
                </el-table-column>
                <el-table-column
                prop="seeroot"
                label="观看权限">
                </el-table-column>
                <el-table-column
                prop="appointnum"
                label="预约人数">
                </el-table-column>
                <el-table-column
                prop="ments"
                label="用户ID">
                </el-table-column>
                <el-table-column
                prop="name"
                label="用户昵称">
                </el-table-column>
                <el-table-column
                label="操作">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="show-color">{{ scope.row.operation }}</span>
                </template>
                </el-table-column>
            </el-table>
        </div>
        <!-- 回放预览 -->
        <el-dialog title="举报人数" :visible.sync="playbackFlag">
            <el-table :data="pbData">
                <el-table-column property="id" label="录像ID"></el-table-column>
                <el-table-column property="videoName" label="录像名称"></el-table-column>
                <el-table-column property="operation" label="生成时间"></el-table-column>
                <el-table-column property="operation" label="操作"></el-table-column>
            </el-table>
        </el-dialog>
         <!-- 内容介绍 -->
        <el-dialog title="内容详情" :visible.sync="contentFlag">
            <el-table :data="contentData">
                <el-table-column property="title" label="标题"></el-table-column>
                <el-table-column property="img" label="图片"></el-table-column>
            </el-table>
            <div slot="footer" class="dialog-footer">
                <el-button @click="contentFlag = false">取 消</el-button>
            </div>
        </el-dialog>
         <!-- 聊天室管理 -->
         <el-dialog title="聊天互动" :visible.sync="chatMFlag">
            <div class="bannedw">全员禁言：
                <el-select v-model="bannedvalue" placeholder="请选择">
                    <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button @click="chatMFlag = false">取 消</el-button>
            </div>
        </el-dialog>
         <!-- 举报人数 -->
       <el-dialog title="举报人数" :visible.sync="repeatFlag">
            <el-table :data="repeatData">
                <el-table-column property="order" label="排序" width="150"></el-table-column>
                <el-table-column property="whistleblowersuserid" label="举报人用户ID" width="200"></el-table-column>
                <el-table-column property="whistleblowersname" label="举报人昵称"></el-table-column>
                <el-table-column property="repeattime" label="举报时间"></el-table-column>
                <el-table-column property="repeatreason" label="举报原因"></el-table-column>
            </el-table>
            <div slot="footer" class="dialog-footer">
                <el-button @click="repeatFlag = false">取 消</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script>
export default {
    data(){
        return {
            playbackFlag:false,
            contentFlag:false,
            chatMFlag:false,
            repeatFlag:false,
            pbData: [
                {
                    id: '169981101425559908',
                    videoName:'录像名称',
                    createTime: '生成时间',
                    operation:'操作'
                }, 
                {
                    id: '169981101425559908',
                    videoName:'录像名称',
                    createTime: '生成时间',
                    operation:'操作'
                }, 
                {
                    id: '169981101425559908',
                    videoName:'录像名称',
                    createTime: '生成时间',
                    operation:'操作'
                }, 
                {
                    id: '169981101425559908',
                    videoName:'录像名称',
                    createTime: '生成时间',
                    operation:'操作'
                }
            ],
             contentData: [
                {
                    title: '标题',
                    img: '图片'
                }, 
                {
                    title: '标题',
                    img: '图片'
                }
            ],
             options: [{
                value: '选项1',
                label: '是'
            }, {
                value: '选项2',
                label: '否'
            }],
            bannedvalue:'否',
            repeatData: [
                {
                    order: '排序',
                    whistleblowersuserid: '举报人用户ID',
                    whistleblowersname: '举报人昵称',
                    repeattime:'举报时间',
                    repeatreason:'举报原因'
                }, 
                {
                    order: '序号',
                    whistleblowersuserid: '举报人用户ID',
                    whistleblowersname: '举报人昵称',
                    repeattime:'举报时间',
                    repeatreason:'举报原因'
                }, 
                {
                    order: '序号',
                    whistleblowersuserid: '举报人用户ID',
                    whistleblowersname: '举报人昵称',
                    repeattime:'举报时间',
                    repeatreason:'举报原因'
                }, 
                {
                    order: '序号',
                    whistleblowersuserid: '举报人用户ID',
                    whistleblowersname: '举报人昵称',
                    repeattime:'举报时间',
                    repeatreason:'举报原因'
                }
            ],
            tableData: [
                {
                    id: '169981101425559908',
                    cover:'直播封面',
                    title: '测试直播2',
                    againpreview:'预览',
                    content:'内容介绍',
                    startTime:'开始时间',
                    torepeat:'0',
                    violations:'封禁',
                    chat:'查看',
                    seeroot:'免费',
                    appointnum:'预约人数',
                    ments:'21',
                    name:'用户昵称',
                    operation:'操作'
                }, 
                {
                    id: '169981101425559908',
                    cover:'直播封面',
                    title: '测试直播2',
                    againpreview:'预览',
                    content:'内容介绍',
                    startTime:'开始时间',
                    torepeat:'0',
                    violations:'封禁',
                    chat:'查看',
                    seeroot:'免费',
                    appointnum:'预约人数',
                    ments:'21',
                    name:'用户昵称',
                    operation:'操作'
                },
                {
                    id: '169981101425559908',
                    cover:'直播封面',
                    title: '测试直播2',
                    againpreview:'预览',
                    content:'内容介绍',
                    startTime:'开始时间',
                    torepeat:'0',
                    violations:'封禁',
                    chat:'查看',
                    seeroot:'免费',
                    appointnum:'预约人数',
                    ments:'21',
                    name:'用户昵称',
                    operation:'操作'
                }, 
                {
                    id: '169981101425559908',
                    cover:'直播封面',
                    title: '测试直播2',
                    againpreview:'预览',
                    content:'内容介绍',
                    startTime:'开始时间',
                    torepeat:'0',
                    violations:'封禁',
                    chat:'查看',
                    seeroot:'免费',
                    appointnum:'预约人数',
                    ments:'21',
                    name:'用户昵称',
                    operation:'操作'
            }]
        }
    },
    methods:{
        playBackP(){
            this.playbackFlag = true;
        },
        contentA(){
            this.contentFlag = true;
        },
        ChatM(){
            this.chatMFlag = true;
        },
        repeatT(){
            this.repeatFlag = true;
        }
    }
}
</script>
<style lang="scss" scoped>
.trailer-search{
    margin: 20px 0;
    .delet{
        float: left;
    }
    .word{
        float: right;
        input{
            display: inline-block;
            height: 30px;
            line-height: 30px;
            padding: 0 10px;
        }
        input::-webkit-input-placeholder{
            color:#ccc;
        }
        input::-moz-placeholder{   /* Mozilla Firefox 19+ */
            color:#ccc;
        }
        input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
            color:#ccc;
        }
        input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
            color:#ccc;
        }
    }
}
.trailer-main{
    .show-color{
        color: #337ab7;
        cursor: pointer;
    }
}
.bannedw{
    display: inline-block;
    .el-select{
        width: 100px;
    }
}
</style>


