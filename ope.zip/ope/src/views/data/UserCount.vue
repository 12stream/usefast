<template>
    <div id="user_count">
        <div class="count-search">
            日期：
            <el-date-picker
            v-model="stime"
            type="date"
            placeholder="选择日期">
            </el-date-picker>
            到
            <el-date-picker
            v-model="etime"
            type="date"
            placeholder="选择日期">
            </el-date-picker>
            <el-button type="primary" plain>查询</el-button>
        </div>
        <div id="userChart" :style="{width: '100%'}"></div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            stime:'',
            etime:''
        }
    },
    methods:{
        showUserData(){
            // 基于准备好的dom，初始化echarts实例
            let myChart = this.$echarts.init(document.getElementById('userChart'))
            // 绘制图表
            myChart.setOption({
                title: {
                    text: '用户统计'
                },
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    data:['注册数']
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                toolbox: {
                    feature: {
                        saveAsImage: {}
                    }
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: ['周一','周二','周三','周四','周五','周六','周日']
                },
                yAxis: {
                    type: 'value'
                },
                series: [
                    {
                        name:'注册数',
                        type:'line',
                        data:[1,5,7,4,1,6,3]
                    }
                ]
            });
        }
    },
    mounted(){
        this.showUserData();
    }
}
</script>
<style lang="scss" scoped>
#user_count{
    background: #fff;
    .count-search{
        padding: 20px;
        border-bottom: 1px solid #e7eaec;
    }
}
#userChart{
    min-height: 300px;
    margin-top: 20px;
}
</style>

