<template>
    <div id="live_anchor_num">
        <div class="anchor-search">
            日期：
            <el-date-picker
            v-model="time"
            type="date"
            placeholder="选择日期">
            </el-date-picker>
            <el-button type="primary" plain>查询</el-button>
        </div>
        <div id="liveChart" :style="{width: '100%'}"></div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            time:''
        }
    },
    methods:{
        showLiveData(){
            // 基于准备好的dom，初始化echarts实例
            let myChart = this.$echarts.init(document.getElementById('liveChart'))
            // 绘制图表
            myChart.setOption({
                title: {
                    text: '用户统计',
                    padding:[0,0,20,20]
                },
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    data:['注册数']
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                toolbox: {
                    feature: {
                        saveAsImage: {}
                    }
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: ['00:00','01:00','02:00','03:00','04:00','05:00','06:00','07:00','08:00','09:00','10:00','11:00','12:00'
                    ,'13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00','22:00','23:00']
                },
                yAxis: {
                    type: 'value'
                },
                series: [
                    {
                        name:'注册数',
                        type:'line',
                        data:[1,5,7,4,1,6,3,4,1,5,2,1,4,1,5,4,1,4,5,2,1,6,3,9]
                    }
                ]
            });
        }
    },
    mounted(){
        this.showLiveData();
    }
}
</script>
<style lang="scss" scoped>
#live_anchor_num{
    background: #fff;
    .anchor-search{
        padding: 20px;
        border-bottom: 1px solid #e7eaec;
    }
}
#liveChart{
    min-height: 300px;
    margin-top: 20px;
}
</style>

