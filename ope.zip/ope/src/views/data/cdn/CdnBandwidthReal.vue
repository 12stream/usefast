<template>
    <div id="cdn_bandwidth_real">
         <div class="real-search">
            粒度：
            <el-select v-model="value" placeholder="请选择">
                <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value">
                </el-option>
            </el-select>
            <el-time-picker
                v-model="value2"
                :picker-options="{
                selectableRange: '18:30:00 - 20:30:00'
                }"
                placeholder="任意时间点">
            </el-time-picker>
            到
            <el-time-picker
                arrow-control
                v-model="value3"
                :picker-options="{
                selectableRange: '18:30:00 - 20:30:00'
                }"
                placeholder="任意时间点">
            </el-time-picker>
            <el-button type="primary" plain>查询</el-button>
        </div>
        <div class="cdn_bandwidth_real_main">
            <div id="realChart" :style="{width: '100%'}"></div>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            options: [
                {
                    value: '选项1',
                    label: '1分钟'
                }, 
                {
                    value: '选项2',
                    label: '5分钟'
                },
                {
                    value: '选项3',
                    label: '10分钟'
                }
            ],
            value:'1分钟',
            value2: new Date(2016, 9, 10, 18, 40),
            value3: new Date(2016, 9, 10, 18, 40)
        }
    },
    methods:{
        realShow(){
             // 基于准备好的dom，初始化echarts实例
            let myChart = this.$echarts.init(document.getElementById('realChart'))
            // 绘制图表
            myChart.setOption({
                // title: {
                //     text: '折线图堆叠'
                // },
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    data:['充值','消费']
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                toolbox: {
                    feature: {
                        saveAsImage: {}
                    }
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: ['周一','周二','周三','周四','周五','周六','周日']
                },
                yAxis: {
                    type: 'value',
                    min:50000,
                    // axisLabel: {
                    //     formatter: function (value, index) {
                    //         if (value >= 10000 && value < 10000) {
                    //             value = value / 10000 + "万";
                    //         } else if (value >= 10000) {
                    //             value = value / 10000 + "万";
                    //         }
                    //             return value;
                    //     }
                    // }
                },
                series: [
                    {
                        name:'充值',
                        type:'line',
                        data:[50000,84700,69800,142500,95200,241500,77700]
                    },
                    {
                        name:'消费',
                        type:'line',
                        data:[88800,99900,214100,63200,96300,125100,74100]
                    }
                ]
            });
        }
    },
    mounted(){
        this.realShow();
    }
}
</script>
<style lang="scss" scoped>
#cdn_bandwidth_real{
    background: #fff;
    .real-search{
        padding: 20px;
        border: 1px solid #ddd;
    }
}
.el-date-editor .el-range-separator{
    padding: 0;
}
.el-date-editor.el-range-editor.el-input__inner.el-date-editor--timerange{
    position: relative;
    top: 4px;
}
#realChart{
    min-height: 300px;
    margin-top: 20px;
}
</style>

