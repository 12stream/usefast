<template>
    <div id="cdn_bandwidth_history">
        <div class="history-search">
            日期：
            <el-date-picker
                v-model="hstime"
                type="date"
                placeholder="选择日期">
            </el-date-picker>
            到
            <el-date-picker
                v-model="hetime"
                type="date"
                placeholder="选择日期">
            </el-date-picker>
            <el-button type="primary" plain>查询</el-button>
        </div>
         <div class="cdn_bandwidth_history_main">
            <div id="historyChart" :style="{width: '100%'}"></div>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            hstime:'',
            hetime:''
        }
    },
    methods:{
         historyShow(){
             // 基于准备好的dom，初始化echarts实例
            let myChart = this.$echarts.init(document.getElementById('historyChart'))
            // 绘制图表
            myChart.setOption({
                // title: {
                //     text: '折线图堆叠'
                // },
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    data:['充值','消费']
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                toolbox: {
                    feature: {
                        saveAsImage: {}
                    }
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: ['周一','周二','周三','周四','周五','周六','周日']
                },
                yAxis: {
                    type: 'value',
                    min:50000,
                    // axisLabel: {
                    //     formatter: function (value, index) {
                    //         if (value >= 10000 && value < 10000) {
                    //             value = value / 10000 + "万";
                    //         } else if (value >= 10000) {
                    //             value = value / 10000 + "万";
                    //         }
                    //             return value;
                    //     }
                    // }
                },
                series: [
                    {
                        name:'充值',
                        type:'line',
                        data:[50000,84700,69800,142500,95200,241500,77700]
                    },
                    {
                        name:'消费',
                        type:'line',
                        data:[88800,99900,214100,63200,96300,125100,74100]
                    }
                ]
            });
        }
    },
    mounted(){
        this.historyShow();
    }
}
</script>
<style lang="scss" scoped>
#cdn_bandwidth_history{
    background: #fff;
    .history-search{
        padding: 20px;
        border: 1px solid #ddd;
    }
}
#historyChart{
    min-height: 300px;
    margin-top: 20px;
}
</style>

