<template>
    <div id="finance_count">
         <div class="finance-search clearfix">
            <div class="tab clearfix">
                <ul>
                    <li v-for="(item,i) in tabContents" :key="i" :class="currentTabsIndex == i ? 'tabs-item active' : 'tabs-item'" @click="selectTabs(i)">{{item}}</li>
                </ul>
            </div>
            <div class="search clearfix">
                日期：
                <el-date-picker
                v-model="fstime"
                type="date"
                placeholder="选择日期">
                </el-date-picker>
                到
                <el-date-picker
                v-model="fetime"
                type="date"
                placeholder="选择日期">
                </el-date-picker>
                <el-button type="primary" plain>查询</el-button>
                <el-button type="primary" plain>最近一周</el-button>
                <el-button type="primary" plain>最近一月</el-button>
                <el-button type="primary" plain>最近一年</el-button>
            </div>
        </div>
        <div class="finance_count_chart">
            <p class="title">充值总金额(元)：0</p>
            <div id="financeChart" :style="{width: '100%'}"></div>
        </div>
        <div class="top-up">
            <p class="title"><strong>详细数据-充值</strong></p>
              <el-table
                :data="tableData"
                stripe
                style="width: 100%">
                    <el-table-column
                    prop="data"
                    label="日期">
                    </el-table-column>
                    <el-table-column
                    prop="consumptionallmoney"
                    label="消费总金额(元)">
                    </el-table-column>

                    <el-table-column
                    prop="consumptionnumber"
                    label="消费笔数(笔)"
                    >
                    </el-table-column>
                </el-table>
        </div>
        <div class="consumption">
            <p class="title"><strong>详细数据-消费</strong></p>
              <el-table
                :data="tableData2"
                stripe
                style="width: 100%">
                    <el-table-column
                    prop="data"
                    label="日期">
                    </el-table-column>
                    <el-table-column
                    prop="consumptionallmoney"
                    label="消费总金额(元)">
                    </el-table-column>

                    <el-table-column
                    prop="consumptionnumber"
                    label="消费笔数(笔)"
                    >
                    </el-table-column>
                </el-table>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            tabContents:['直播服务费','虚拟货币'],
            currentTabsIndex:0,
            fstime:'',
            fetime:'',
            tableData: [
                {
                    data:'日期',
                    consumptionallmoney:'消费总金额(元)',
                    consumptionnumber:'消费笔数(笔)',
                }, 
                {
                    data:'日期',
                    consumptionallmoney:'消费总金额(元)',
                    consumptionnumber:'消费笔数(笔)',
                },
                {
                    data:'日期',
                    consumptionallmoney:'消费总金额(元)',
                    consumptionnumber:'消费笔数(笔)',
                }, 
                {
                    data:'日期',
                    consumptionallmoney:'消费总金额(元)',
                    consumptionnumber:'消费笔数(笔)',
            }],
            tableData2: [
                {
                    data:'日期',
                    consumptionallmoney:'消费总金额(元)',
                    consumptionnumber:'消费笔数(笔)',
                }, 
                {
                    data:'日期',
                    consumptionallmoney:'消费总金额(元)',
                    consumptionnumber:'消费笔数(笔)',
                },
                {
                    data:'日期',
                    consumptionallmoney:'消费总金额(元)',
                    consumptionnumber:'消费笔数(笔)',
                }, 
                {
                    data:'日期',
                    consumptionallmoney:'消费总金额(元)',
                    consumptionnumber:'消费笔数(笔)',
            }]
        }
    },
    methods:{
        selectTabs(val){
            this.currentTabsIndex = val;
        },
        showFinance(){
            // 基于准备好的dom，初始化echarts实例
            let myChart = this.$echarts.init(document.getElementById('financeChart'))
            // 绘制图表
            myChart.setOption({
                // title: {
                //     text: '折线图堆叠'
                // },
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    data:['充值','消费']
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                toolbox: {
                    feature: {
                        saveAsImage: {}
                    }
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: ['周一','周二','周三','周四','周五','周六','周日']
                },
                yAxis: {
                    type: 'value',
                    min:50000,
                    // axisLabel: {
                    //     formatter: function (value, index) {
                    //         if (value >= 10000 && value < 10000) {
                    //             value = value / 10000 + "万";
                    //         } else if (value >= 10000) {
                    //             value = value / 10000 + "万";
                    //         }
                    //             return value;
                    //     }
                    // }
                },
                series: [
                    {
                        name:'充值',
                        type:'line',
                        data:[50000,84700,69800,142500,95200,241500,77700]
                    },
                    {
                        name:'消费',
                        type:'line',
                        data:[88800,99900,214100,63200,96300,125100,74100]
                    }
                ]
            });
        }
    },
    mounted(){
        this.showFinance();
    }
}
</script>
<style lang="scss" scoped>
.finance-search{
    background: #fff;
    border-bottom: 1px solid #ddd;
    .tab{
        padding: 35px 20px 10px;
        float: left;
        ul{
            li{
                padding: 10px 20px 10px 25px;
                display: inline-block;
                &.active{
                    border: 1px solid #ddd;
                    border-bottom: 3px solid #35C1FC;
                }
            }
        }
    }
    .search{
        float: right;
        padding: 35px 20px 0 0;
    }
}
.el-date-editor.el-input,.el-date-editor.el-input__inner{
    width: 150px;
}
.finance_count_chart{
    background: #fff;
    p{
        padding: 5px 20px;
        border-bottom: 1px solid #ddd;
    }
    #financeChart{
        min-height: 300px;
    }
}
.top-up,.consumption{
    p{
        margin: 5px 0;
        strong{
            font-size: 16px;
        }
    }
}
</style>

