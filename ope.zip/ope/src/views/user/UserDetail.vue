<template>
    <div class="userdetail">
        <div class="tab clearfix">
            <div class="live-status clearfix" v-for="(item,i) in tabContents" :key="i">
                <div :class="currentTabsIndex == item.type ? 'tabs-item active' : 'tabs-item'" @click="selectTabs(item)">
                    {{item.title}}
                </div>
            </div>
        </div>
        <Detail v-show="currentTabsIndex == 'detail'"></Detail>
        <LiveDetail v-show="currentTabsIndex == 'live'"></LiveDetail>
        <PlaybackDetail v-show="currentTabsIndex == 'playback'"></PlaybackDetail>
        <TrailerDetail v-show="currentTabsIndex == 'trailer'"></TrailerDetail>
        <HistoryLive v-show="currentTabsIndex == 'history'"></HistoryLive>
    </div>
</template>
<script>
import Detail from './components/Detail'
import LiveDetail from './components/LiveDetail'
import PlaybackDetail from './components/PlaybackDetail'
import  TrailerDetail from './components/TrailerDetail'
import HistoryLive from './components/HistoryLive'
import eventVue from '@/components/eventVue.js'
export default {
    data(){
        return {
            tabContents:[{
                title:'用户详情',
                type:'detail'
            }],
            tabFlag:'detail',
            currentTabsIndex:'detail',
        }
    },
    components:{Detail, LiveDetail, PlaybackDetail, TrailerDetail, HistoryLive},
    methods:{
        selectTabs(val){
            this.currentTabsIndex = val.type;
        },
    },
    mounted(){
        eventVue.$on('usertab',val =>{
            if(this.tabFlag.indexOf(val.type) == -1){
                this.tabContents.push(val);
                this.tabFlag = this.tabFlag+val.type;
            }
            this.currentTabsIndex = val.type;
        })
    }
}
</script>
<style lang="scss" scoped>
.tab{
    overflow: hidden;
    border-bottom: 1px solid #ddd;
    height: 44px;
    line-height: 44px;
    .live-status{
        float: left;
        .tabs-item{
            color: #676a6c;
            padding: 0 20px;
            &.active{
                color: #333;
                border: 1px solid #ddd;
                border-bottom: 0;
            }
        }
    }
}
</style>

