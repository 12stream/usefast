<template>
    <div id="user_manage">
        <div class="search-user">
            排序：
            <el-select v-model="value" placeholder="请选择">
                <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value">
                </el-option>
            </el-select>
            <div class="rchoice">
                <el-radio v-model="radio" label="1" class="one">所有用户</el-radio>
                <el-radio v-model="radio" label="2">封禁用户</el-radio>
            </div>
            <div class="check-user">
                <input type="text" placeholder="请输入ID、昵称或手机号码">
                <el-button type="primary" plain>查询</el-button>
            </div>
        </div>
        <div class="user-manage-main">
            <el-table
            :data="tableData"
            stripe
            style="width: 100%">
                <el-table-column
                prop="id"
                label="直播间ID"
                >
                </el-table-column>
                <el-table-column
                prop="userimg"
                label="用户头像"
                >
                </el-table-column>
                <el-table-column
                prop="username"
                label="用户昵称">
                </el-table-column>
                <el-table-column
                prop="phoneNumber"
                label="手机号码">
                </el-table-column>
                <el-table-column
                prop="registertime"
                label="注册时间">
                </el-table-column>
                <el-table-column
                prop="fans"
                label="粉丝人数">
                </el-table-column>
                <el-table-column
                prop="type"
                label="后台帐号类型">
                </el-table-column>
                <el-table-column
                prop="bannedstatus"
                label="封禁状态">
                </el-table-column>
                <el-table-column
                label="用户详情">
                 <template slot-scope="scope">
                    <span style="margin-left: 10px" class="detail" @click="toDetail">{{ scope.row.userdetail }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="举报人数">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="detail" @click="repeat">{{ scope.row.repeatnumber }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="操作">
                <template slot-scope="scope">
                    <span style="margin-left: 10px" class="detail">{{ scope.row.operate }}</span>
                </template>
                </el-table-column>
            </el-table>
        </div>
        <!-- 举报人数 -->
        <el-dialog title="举报详情" :visible.sync="dialogTableVisible" class="">
        <el-table :data="gridData">
            <el-table-column property="order" label="序号" width="150"></el-table-column>
            <el-table-column property="whistleblowersuserid" label="举报人用户ID" width="200"></el-table-column>
            <el-table-column property="whistleblowersname" label="举报人昵称"></el-table-column>
            <el-table-column property="repeattime" label="举报时间"></el-table-column>
            <el-table-column property="repeatreason" label="举报原因"></el-table-column>
            <el-table-column property="repeatsource" label="举报来源"></el-table-column>
        </el-table>
        <div slot="footer" class="dialog-footer">
            <el-button @click="dialogTableVisible = false">取 消</el-button>
        </div>
        </el-dialog>
    </div>
</template>
<script>
export default {
    data(){
        return {
            dialogTableVisible:false,
            gridData: [
                {
                    order: '序号',
                    whistleblowersuserid: '举报人用户ID',
                    whistleblowersname: '举报人昵称',
                    repeattime:'举报时间',
                    repeatreason:'举报原因',
                    repeatsource:'举报来源'
                }, 
                {
                    order: '序号',
                    whistleblowersuserid: '举报人用户ID',
                    whistleblowersname: '举报人昵称',
                    repeattime:'举报时间',
                    repeatreason:'举报原因',
                    repeatsource:'举报来源'
                }, 
                {
                    order: '序号',
                    whistleblowersuserid: '举报人用户ID',
                    whistleblowersname: '举报人昵称',
                    repeattime:'举报时间',
                    repeatreason:'举报原因',
                    repeatsource:'举报来源'
                }, 
                {
                    order: '序号',
                    whistleblowersuserid: '举报人用户ID',
                    whistleblowersname: '举报人昵称',
                    repeattime:'举报时间',
                    repeatreason:'举报原因',
                    repeatsource:'举报来源'
                }
            ],
            radio:'1',
            options: [
                {
                    value: '选项1',
                    label: '注册时间'
                }, 
                {
                    value: '选项2',
                    label: '粉丝人数'
                }
            ],
            value: '',
            tableData: [
                {
                    id: '169981101425559908',
                    userimg: '用户头像',
                    username: '用户昵称',
                    phoneNumber:'手机号码',
                    registertime:'注册时间',
                    fans:'粉丝人数',
                    type:'后台帐号类型',
                    bannedstatus:'封禁状态',
                    userdetail:'详情',
                    repeatnumber:'0',
                    operate:'封禁'
                }, 
                {
                    id: '169981101425559908',
                    userimg: '用户头像',
                    username: '用户昵称',
                    phoneNumber:'手机号码',
                    registertime:'注册时间',
                    fans:'粉丝人数',
                    type:'后台帐号类型',
                    bannedstatus:'封禁状态',
                    userdetail:'详情',
                    repeatnumber:'0',
                    operate:'封禁'
                },
                {
                    id: '169981101425559908',
                    userimg: '用户头像',
                    username: '用户昵称',
                    phoneNumber:'手机号码',
                    registertime:'注册时间',
                    fans:'粉丝人数',
                    type:'后台帐号类型',
                    bannedstatus:'封禁状态',
                    userdetail:'详情',
                    repeatnumber:'0',
                    operate:'封禁'
                }, 
                {
                    id: '169981101425559908',
                    userimg: '用户头像',
                    username: '用户昵称',
                    phoneNumber:'手机号码',
                    registertime:'注册时间',
                    fans:'粉丝人数',
                    type:'后台帐号类型',
                    bannedstatus:'封禁状态',
                    userdetail:'详情',
                    repeatnumber:'0',
                    operate:'封禁'
            }]
        }
    },
    methods:{
        toDetail(){
            this.$router.push({path:'/user/user_detail'})
        },
        repeat(){
            this.dialogTableVisible = true;
        }
    }
}
</script>
<style lang="scss" scoped>
.search-user{
    text-align: right;
    .rchoice{
        display:inline-block;
        margin: 0 10px;
        .el-radio{
            margin: 0;
            &.one{
                margin-right: 5px;
            }
        }
    }
    .check-user{
        display: inline-block;
        input{
            display: inline-block;
            height: 30px;
            line-height: 30px;
            padding: 0 10px;
        }
        input::-webkit-input-placeholder{
            color:#ccc;
        }
        input::-moz-placeholder{   /* Mozilla Firefox 19+ */
            color:#ccc;
        }
        input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
            color:#ccc;
        }
        input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
            color:#ccc;
        }
    }
}
.user-manage-main{
    margin-top: 20px;
    .cell{
        .detail{
            color: #337ab7;
            cursor: pointer;
        }
    }
}
</style>

