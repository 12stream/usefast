<template>
    <div id="user">
        <div class="userinfo">
            <h3>账户预览</h3>
            <el-row>
                <el-col :span="6"><div class="grid-content bg-purple">
                    <div class="show">
                        <p class="title">注册总用户（人）</p>
                        <p class="num">102,400</p>
                    </div>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple">
                    <div class="show">
                        <p class="title">最近30天活跃用户（人）</p>
                        <p class="num">1,024</p>
                    </div>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple">
                    <div class="show">
                        <p class="title">最近30天直播总时长（分钟）</p>
                        <p class="num">2,632</p>
                    </div>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple">
                    <div class="show">
                        <p class="title">最近30天观看总时长（分钟）</p>
                        <p class="num">7,078</p>
                    </div>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple">
                    <div class="show">
                        <p class="title">最近30天充值总金额（元）</p>
                        <p class="num">81,024.06</p>
                    </div>
                </div></el-col>
                <el-col :span="6"><div class="grid-content bg-purple">
                    <div class="show">
                        <p class="title">最近30天消费总金额（元）</p>
                        <p class="num">2,320.00</p>
                    </div>
                </div></el-col>
            </el-row>
        </div>
        <div class="consumption">
            <h3>消费概览</h3>
            <div class="user-data">
                <div class="top-up-consumption clearfix">
                    <div class="top-up clearfix">
                        <p class="title">充值总金额</p>
                        <p class="money">124,543.00<sub>元</sub></p>
                    </div>
                    <div class="cons clearfix">
                        <p class="title">消费总金额</p>
                        <p class="money">203,543.00<sub>元</sub></p>
                    </div>
                </div>
                <div class="search clearfix">
                    <div class="time">
                        筛选：
                        <el-date-picker
                        v-model="value1"
                        type="date"
                        placeholder="选择日期">
                        </el-date-picker>
                        -
                        <el-date-picker
                        v-model="value1"
                        type="date"
                        placeholder="选择日期">
                        </el-date-picker>
                        <el-button type="primary">查询</el-button>
                        <div class="choice-time">
                            <span>本月</span>
                            <span>最近30天</span>
                            <span>最近一年</span>
                        </div>
                    </div>
                </div>
            </div>
            <div id="myChart" :style="{width: '100%'}"></div>
        </div>
    </div>
</template>
<script>
import {dateRnag} from '@/utils/utils'
export default {
    data(){
        return {
            showMenuTitle:'',
            value1:'',
            obj:{"resultCode":"01","resultMsg":"受理成功","params":{"2018-03":{"rechargeTotal":0.0,"consumeTotal":0.0,"bitrate":2316.8},"2018-02":{"rechargeTotal":0.0,"consumeTotal":0.0,"bitrate":5491.2},"2018-01":{"rechargeTotal":0.0,"consumeTotal":0.0,"bitrate":8256.0},"2018-07":{"rechargeTotal":14806.1,"consumeTotal":56.25,"bitrate":7154.4},"2018-06":{"rechargeTotal":0.0,"consumeTotal":0.0,"bitrate":5255.2},"2018-05":{"rechargeTotal":0.0,"consumeTotal":0.0,"bitrate":14120.0},"2018-04":{"rechargeTotal":0.0,"consumeTotal":0.0,"bitrate":12960.8},"2018-11":{"rechargeTotal":10000.01,"consumeTotal":332.75,"bitrate":0.0},"2018-12":{"rechargeTotal":0.0,"consumeTotal":0.0,"bitrate":0.0},"2019-01":{"rechargeTotal":0.0,"consumeTotal":0.0,"bitrate":0.0},"2018-08":{"rechargeTotal":1178104.17,"consumeTotal":1156.84,"bitrate":7233.6},"2018-09":{"rechargeTotal":840800.1,"consumeTotal":698.75,"bitrate":4246.4},"2018-10":{"rechargeTotal":11065.0,"consumeTotal":186.65,"bitrate":260.8}},"paramo":null},
            list:[],
            rechargeTotal:[],
            consumeTotal:[]
        }
    },
    methods:{
        test(arr){
            arr.sort((a,b) =>{
                return b[0]['created_date'] < a[0]['created_date'] ? 1 : -1 ;
            })
        },
         drawLine() {
             var res = dateRnag(this.obj['params']);
             for(var i in res){
                 this.list.push(i);
                 this.rechargeTotal.push(res[i].rechargeTotal);
                 this.consumeTotal.push(res[i].consumeTotal);
             }
            // 基于准备好的dom，初始化echarts实例
            let myChart = this.$echarts.init(document.getElementById('myChart'))
            // 绘制图表
            myChart.setOption({
                // title: {
                //     text: '折线图堆叠'
                // },
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    data:['充值','消费']
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                toolbox: {
                    feature: {
                        saveAsImage: {}
                    }
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: this.list
                },
                yAxis: {
                    type: 'value',
                    // axisLabel: {
                    //     formatter: function (value, index) {
                    //         if (value >= 10000 && value < 10000) {
                    //             value = value / 10000 + "万";
                    //         } else if (value >= 10000) {
                    //             value = value / 10000 + "万";
                    //         }
                    //             return value;
                    //     }
                    // }
                },
                series: [
                    {
                        name:'充值',
                        type:'line',
                        data:this.rechargeTotal
                    },
                    {
                        name:'消费',
                        type:'line',
                        data:this.consumeTotal
                    }
                ]
            });
        }
    },
    mounted(){
        this.drawLine();
    }
    
}
</script>
<style lang="scss" scoped>
.userinfo {
    background: #fff;
    h3{
        padding: 7px 0 6px 16px;
        font-weight:500;
    }
    .grid-content {
        border: 1px solid #F2F2F2;
        text-align: center;
        .show{
            .title{
                margin: 15px 0 7px 0;
            }
            .num{
                padding-bottom: 20px;
            }
        }
    }
}
.consumption{
    background: #fff;
    height: 100%;
    margin-top: 20px;
    h3{
        padding: 7px 0 6px 16px;
        border: 1px solid #F2F2F2;
    }
    .user-data{
        height: 100%;
        .top-up-consumption{
            float: left;
            margin-left: 16px;
            margin-top: 12px;
            .top-up{
                float: left;
                padding-right: 32px;
                border-right: 1px solid #F2F2F2;
            }
            .cons{
                float: left;
                padding-left: 16px;
            }
            .title{
                color: #979797;
                margin-bottom: 8px;
                font-size: 12px;
            }
            .money{
                font-size: 20px;
                sub{
                    font-size: 12px;
                    position: relative;
                    left: 2px;
                    top: -6px;
                }
            }
        }
        .time{
            float: right;
            margin-top: 12px;
            margin-right: 16px;
            // button{
            //     width: 60px;
            //     height: 30px;
            //     line-height: 30px;
            //     text-align: center;
            //     background: #D9D9D9;
            //     color: #BFBFBF;
            //     font-size: 14px;
            //     border-radius: 2px;
            // }
            .choice-time{
                display: inline-block;
                margin-left: 16px;
               span{
                    width: 74px;
                    height: 30px;
                    text-align: center;
                    line-height: 30px;
                    border: 1px solid #F2F2F2;
                    display: inline-block;
               }
            }
        }
    }
    #myChart{
        min-height: 300px;
        margin-top: 20px;
    }
}
</style>

