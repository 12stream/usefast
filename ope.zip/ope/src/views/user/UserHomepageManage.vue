<template>
    <div id="user_homepage_manage">
        <el-button @click="goUserDetail">返回</el-button>
         <div class="homepage-search clearfix">
            日期：
            <el-date-picker
            v-model="time1"
            type="date"
            placeholder="开始时间">
            </el-date-picker>
            <el-date-picker
            v-model="time2"
            type="date"
            placeholder="结束时间">
            </el-date-picker>
            <input type="text" placeholder="请输入主页名称">
            <el-button type="primary" plain>查询</el-button>
        </div>
        <div class="homepage-main">
            <el-table
            :data="tableData"
            stripe
            style="width: 100%">
                <el-table-column
                prop="homemessage"
                label="主页信息">
                </el-table-column>
                <el-table-column
                prop="createtime"
                label="创建时间">
                </el-table-column>
                <el-table-column
                prop="accessnumber"
                label="访问数">
                </el-table-column>
                <el-table-column
                prop="preview"
                label="浏览量">
                </el-table-column>
                <el-table-column
                prop="status"
                label="状态">
                </el-table-column>
                <el-table-column
                prop="operate"
                label="操作">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            time1:'',
            time2:'',
            tableData: [
                {
                    homemessage: '主页信息',
                    createtime: '创建时间',
                    accessnumber:'访问数',
                    preview:'浏览量',
                    status:'2',
                    operate:'操作'
                }, 
                {
                    homemessage: '主页信息',
                    createtime: '创建时间',
                    accessnumber:'访问数',
                    preview:'浏览量',
                    status:'2',
                    operate:'操作'
                },
                {
                    homemessage: '主页信息',
                    createtime: '创建时间',
                    accessnumber:'访问数',
                    preview:'浏览量',
                    status:'2',
                    operate:'操作'
                }, 
                {
                    homemessage: '主页信息',
                    createtime: '创建时间',
                    accessnumber:'访问数',
                    preview:'浏览量',
                    status:'2',
                    operate:'操作'
            }]
        }
    },
    methods:{
        goUserDetail(){
            this.$router.push({path:"/user/user_detail"});
        }
    }
}
</script>
<style lang="scss" scoped>
.homepage-search{
    margin-top: 20px;
    text-align: right;
    input{
        display: inline-block;
        height: 30px;
        line-height: 30px;
        padding: 0 10px;
    }
    input::-webkit-input-placeholder{
        color:#ccc;
    }
    input::-moz-placeholder{   /* Mozilla Firefox 19+ */
        color:#ccc;
    }
    input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
        color:#ccc;
    }
    input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
        color:#ccc;
    }
}
.homepage-main{
    margin-top: 20px;
}
</style>

