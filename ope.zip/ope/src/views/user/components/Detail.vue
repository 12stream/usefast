<template>
    <div class="detail">
        <div class="userdetail-main">
            <div class="userinfo">
                <el-row>
                    <el-col :span="8" class="userimg">
                        <h3 class="title">3877</h3>
                        <p class="img"><img src="http://img5.duitang.com/uploads/item/201411/07/20141107164412_v284V.jpeg" alt="404"></p>
                    </el-col>
                    <el-col :span="16" class="info">
                        <h3>基本信息</h3>
                        <p>简介：</p>
                        <p>关注数：5</p>
                    </el-col>
                </el-row>
            </div>
            <div class="live-message">
                <h3>直播信息</h3>
                <p>
                    <span class="left clearfix">当前直播个数：0</span>
                    <span class="right clearfix" @click="live">查看详情</span>
                </p>
                <p>
                    <span class="left clearfix">当前回放个数：0</span>
                    <span class="right clearfix" @click="playback">查看详情</span>
                </p>
                <p>
                    <span class="left clearfix">当前预告个数：0</span>
                    <span class="right clearfix" @click="trailer">查看详情</span>
                </p>
                <p>
                    <span class="left clearfix">历史直播：0</span>
                    <span class="right clearfix" @click="history">查看详情</span>
                </p>
            </div>
            <div class="banned">
                <h3>封禁信息</h3>
                <p>封禁状态：正常</p>
                <p>直播间封禁个数：0</p>
            </div>
            <div class="usermessage">
                <h3>账户信息</h3>
                <p>梦豆余额：0</p>
                <p>梦币充值总额：0</p>
                <p>通讯费余额：10</p>
                <p>通讯费充值总额：0</p>
                <p>提现总额：0.00</p>
                <p>
                    <span class="left clearfix">存储空间：0  GB/10  GB</span>
                    <span class="right clearfix" @click="changeStorage">更改存储空间</span>
                </p>
                <p>
                    <span class="left clearfix">主页个数：0</span>
                    <span class="right clearfix" @click="personalPage">个人主页</span>
                </p>
                <p>
                    <span class="left clearfix">点播个数：0</span>
                    <span class="right clearfix" @click="goUserVideo">点播管理</span>
                </p>
            </div>
        </div>
        <el-dialog title="增值服务" :visible.sync="spaceFlag">
        <el-row :gutter="20">
            <el-col :span="4"><div class="grid-content bg-purple">云播号</div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">800527</div></el-col>
        </el-row>
        <el-row :gutter="20">
            <el-col :span="4"><div class="grid-content bg-purple">增值服务</div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">服务类型</div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">服务结束时间</div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">服务升级（00表示永久）</div></el-col>
            <el-col :span="8" class="money"><div class="grid-content bg-purple">金额（元）</div></el-col>
        </el-row>
        <el-row :gutter="20">
            <el-col :span="4" class="widthout"><div class="grid-content bg-purple">.</div></el-col>
            <el-col :span="4" class="space"><div class="grid-content bg-purple"><span @click="setSpace" :class="showSpaceChoice ? 'sborder' : ''">扩容<img src="@/components/images/pop_ic_selected.png" alt="404" v-if="showSpaceChoice"></span></div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">--</div></el-col>
            <el-col :span="4" class="month"><div class="grid-content bg-purple"><input type="number" v-model="month"> 个月</div></el-col>
            <el-col :span="4" class="gb"><div class="grid-content bg-purple"><input type="number" v-model="space"> GB</div></el-col>
            <el-col :span="4" class="entermoney"><div class="grid-content bg-purple"><input type="text"></div></el-col>
        </el-row>
        <el-row :gutter="20">
            <el-col :span="4" class="pay-way"><div class="grid-content bg-purple"><span>支付方式</span></div></el-col>
            <el-col :span="4" class="balance"><div class="grid-content bg-purple"><span>余额支付<img src="@/components/images/pop_ic_selected.png" alt="404"></span></div></el-col>
        </el-row>
        <el-row :gutter="20">
            <el-col :span="4"><div class="grid-content bg-purple">支付总金额</div></el-col>
            <el-col :span="4"><div class="grid-content bg-purple">0</div></el-col>
        </el-row>
        <div slot="footer" class="dialog-footer">
            <el-button @click="spaceFlag = false">取 消</el-button>
            <el-button type="primary" @click="spaceFlag = false">确 定</el-button>
        </div>
        </el-dialog>
    </div>
</template>
<script>
import eventVue from '@/components/eventVue.js'
export default {
    data(){
        return {
            spaceFlag:false,
            month:0,
            space:1,
            showSpaceChoice:false,
        }
    },
    methods:{
         personalPage(){
            this.$router.push({path:'/user/user_homepage_manage'})
        },
        live(){
            eventVue.$emit('usertab',{
                title:'当前直播详情',
                type:'live'
            });
        },
        playback(){
            eventVue.$emit('usertab',{
                title:'当前回放详情',
                type:'playback'
            });
        },
        trailer(){
            eventVue.$emit('usertab',{
                title:'当前预告详情',
                type:'trailer'
            });
        },
        history(){
            eventVue.$emit('usertab',{
                title:'历史直播',
                type:'history'
            });
        },
        changeStorage(){
            this.spaceFlag = true;
        },
        setSpace(){
            this.showSpaceChoice = !this.showSpaceChoice;
        },
        goUserVideo(){
            this.$router.push({path:"/user/user_video_manage"});
        }
    }
}
</script>
<style lang="scss" scoped>
.userdetail-main{
    background: #fff;
    padding-bottom: 70px;
    .userinfo{
        .userimg,.info{
            h3{
                font-size: 24px;
                padding: 20px 0 10px;
                &.title{
                    text-align: center;
                }
            }
            p{
                padding-bottom: 20px;
                &.img{
                    text-align: center;
                }
                img{
                    width: 62px;
                    height: 62px;
                    border-radius: 50%;
                }
            }
        }
        
    }
    .live-message,.banned,.usermessage{
        margin-top: 35px;
        h3{
            margin-left: 20px;
            font-size: 14px;
            font-weight: 700;
        }
        p{
            margin-left: 20px;
            padding: 10px 0;
            margin-right: 20px;
            border-bottom: 1px solid #ddd;
            height: 44px;
            .left{
                float: left;
            }
            .right{
                float: right;
                color: #337ab7;
                cursor: pointer;
            }
        }
    }
}
.money{
    text-align: right;
}
.el-row{
    padding: 8px;
}
.space,.balance{
    div{
        span{
            border: 1px solid #c2c2c2;
            display: inline-block;
            width: 80px;
            height: 32px;
            line-height: 32px;
            text-align: center;
            position: relative;
            &.sborder {
                border-color: #1890ff;
            }
            img{
                position: absolute;
                right: 0;
                bottom: -1px;
            }
        }
    }
}
.month,.gb,.entermoney{
    input{
        border: 1px solid #c2c2c2;
        display: inline-block;
        width: 80px;
        height: 32px;
        line-height: 32px;
        text-align: center;
    }
}
.entermoney{
    text-align: right;
}
.pay-way{
    span{
        display: inline-block;
        height: 32px;
        line-height: 32px;
    }
}
.widthout{
    div{
        transform: scale(0.1);
    }
}
</style>
