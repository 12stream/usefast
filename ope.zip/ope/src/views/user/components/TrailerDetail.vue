<template>
    <div class="trailer-detail">
        <el-table
        :data="tableData"
        stripe
        style="width: 100%">
            <el-table-column
            prop="id"
            label="直播间ID">
            </el-table-column>
            <el-table-column
            prop="cover"
            label="预告封面">
            </el-table-column>
            <el-table-column
            prop="title"
            label="预告标题">
            </el-table-column>
            <el-table-column
            prop="startTime"
            label="开始时间">
            </el-table-column>
            <el-table-column
            prop="seeroot"
            label="观看权限">
            </el-table-column>
            <el-table-column
            prop="trailernumber"
            label="预约人数">
            </el-table-column>
        </el-table>
    </div>
</template>
<script>
export default {
    data(){
        return {
            tableData: [
                {
                    id: '169981101425559908',
                    cover:'直播封面',
                    title: '测试直播2',
                    startTime:'开始时间',
                    seeroot:'免费',
                    trailernumber:'预约人数'
                    
                }, 
                {
                    id: '169981101425559908',
                    cover:'直播封面',
                    title: '测试直播2',
                    startTime:'开始时间',
                    seeroot:'免费',
                    trailernumber:'预约人数'
                },
                {
                    id: '169981101425559908',
                    cover:'直播封面',
                    title: '测试直播2',
                    startTime:'开始时间',
                    seeroot:'免费',
                    trailernumber:'预约人数'
                }, 
                {
                    id: '169981101425559908',
                    cover:'直播封面',
                    title: '测试直播2',
                    startTime:'开始时间',
                    seeroot:'免费',
                    trailernumber:'预约人数'
            }]
        }
    }
}
</script>
<style lang="scss" scoped>

</style>
