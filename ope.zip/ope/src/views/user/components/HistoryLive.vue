<template>
    <div class="history-live">
        <el-table
        :data="tableData"
        stripe
        style="width: 100%">
        <el-table-column
            prop="livepreview"
            label="直播预览">
            </el-table-column>
            <el-table-column
            prop="id"
            label="直播间ID">
            </el-table-column>
            <el-table-column
            prop="cover"
            label="直播封面">
            </el-table-column>
            <el-table-column
            prop="title"
            label="直播标题">
            </el-table-column>
            <el-table-column
            prop="content"
            label="内容介绍">
            </el-table-column>
            <el-table-column
            prop="startTime"
            label="开始时间">
            </el-table-column>
            <el-table-column
            prop="seeroot"
            label="观看权限">
            </el-table-column>
             <el-table-column
            prop="seenumber"
            label="观看人次">
            </el-table-column>
            <el-table-column
            prop="income"
            label="付费观看收入(梦币)">
            </el-table-column>
            <el-table-column
            prop="seetime"
            label="观看时长">
            </el-table-column>
        </el-table>
    </div>
</template>
<script>
export default {
    data(){
        return {
             tableData: [
                {
                    livepreview:'预览',
                    id: '169981101425559908',
                    cover:'直播封面',
                    title: '测试直播2',
                    content:'内容介绍',
                    startTime:'开始时间',
                    seeroot:'免费',
                    seenumber:'观看人次',
                    income: '付费观看收入(梦币)',
                    seetime:'观看时长'
                }, 
                {
                    livepreview:'预览',
                    id: '169981101425559908',
                    cover:'直播封面',
                    title: '测试直播2',
                    content:'内容介绍',
                    startTime:'开始时间',
                    seeroot:'免费',
                    seenumber:'观看人次',
                    income: '付费观看收入(梦币)',
                    seetime:'观看时长'
                },
                {
                    livepreview:'预览',
                    id: '169981101425559908',
                    cover:'直播封面',
                    title: '测试直播2',
                    content:'内容介绍',
                    startTime:'开始时间',
                    seeroot:'免费',
                    seenumber:'观看人次',
                    income: '付费观看收入(梦币)',
                    seetime:'观看时长'
                }, 
                {
                    livepreview:'预览',
                    id: '169981101425559908',
                    cover:'直播封面',
                    title: '测试直播2',
                    content:'内容介绍',
                    startTime:'开始时间',
                    seeroot:'免费',
                    seenumber:'观看人次',
                    income: '付费观看收入(梦币)',
                    seetime:'观看时长'
            }]
        }
    }
}
</script>
<style lang="scss" scoped>

</style>
