<template>
    <div class="user-video-manage">
        <el-button @click="goUserDetail">返回</el-button>
        <div class="user-video-search clearfix">
            <div class="delet clearfix">
                <el-button type="primary">批量删除</el-button>
            </div>
            <div class="word clearfix">
                日期：
                <el-date-picker
                v-model="time1"
                type="date"
                placeholder="开始时间">
                </el-date-picker>
                <el-date-picker
                v-model="time2"
                type="date"
                placeholder="结束时间">
                </el-date-picker>
                <input type="text" placeholder="请输入关键字筛选">
                <el-button type="primary" plain>查询</el-button>
            </div>
        </div>
        <div class="user-video-main">
            <el-table
            :data="tableData"
            stripe
            style="width: 100%">
                <el-table-column
                type="selection">
                </el-table-column>
                <el-table-column
                prop="videomessage"
                label="视频信息">
                </el-table-column>
                <el-table-column
                prop="userinfo"
                label="用户信息">
                </el-table-column>
                <el-table-column
                prop="uploadtime"
                label="上传时间">
                </el-table-column>
                <el-table-column
                prop="seeroot"
                label="观看权限">
                </el-table-column>
                <el-table-column
                prop="access"
                label="访问数">
                </el-table-column>
                <el-table-column
                prop="views"
                label="浏览量">
                </el-table-column>
                <el-table-column
                prop="status"
                label="状态">
                </el-table-column>
                <el-table-column
                prop="videotime"
                label="视频时长">
                </el-table-column>
                <el-table-column
                prop="videosize"
                label="视频大小">
                </el-table-column>
                <el-table-column
                prop="livepreview"
                label="操作">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            time1:'',
            time2:'',
            tableData: [
                {
                    videomessage: '视频信息',
                    userinfo: '用户',
                    uploadtime:'上传时间',
                    seeroot:'免费',
                    access:'21',
                    views:'454',
                    status:'2',
                    videotime:'视频时长',
                    videosize:'大小',
                    livepreview:'观看人次'
                }, 
                {
                    videomessage: '视频信息',
                    userinfo: '用户',
                    uploadtime:'上传时间',
                    seeroot:'免费',
                    access:'21',
                    views:'454',
                    status:'2',
                    videotime:'视频时长',
                    videosize:'大小',
                    livepreview:'观看人次'
                },
                {
                   videomessage: '视频信息',
                    userinfo: '用户',
                    uploadtime:'上传时间',
                    seeroot:'免费',
                    access:'21',
                    views:'454',
                    status:'2',
                    videotime:'视频时长',
                    videosize:'大小',
                    livepreview:'观看人次'
                }, 
                {
                    videomessage: '视频信息',
                    userinfo: '用户',
                    uploadtime:'上传时间',
                    seeroot:'免费',
                    access:'21',
                    views:'454',
                    status:'2',
                    videotime:'视频时长',
                    videosize:'大小',
                    livepreview:'观看人次'
            }]
        }
    },
    methods:{
        goUserDetail(){
            this.$router.push({path:"/user/user_detail"});
        }
    }
}
</script>
<style lang="scss" scoped>
.user-video-search{
    margin: 20px 0;
    .delet{
        float: left;
    }
    .word{
        float: right;
        input{
            display: inline-block;
            height: 30px;
            line-height: 30px;
            padding: 0 10px;
        }
        input::-webkit-input-placeholder{
            color:#ccc;
        }
        input::-moz-placeholder{   /* Mozilla Firefox 19+ */
            color:#ccc;
        }
        input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
            color:#ccc;
        }
        input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
            color:#ccc;
        }
    }
}
</style>
