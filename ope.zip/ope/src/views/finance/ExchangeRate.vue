<template>
    <div id="exchange_rate">
        <h3>充值比例</h3>
        <div class="ios">
            <span><strong>IOS</strong></span>
            <input type="text" readonly="readonly" placeholder="1元">
            <span class="change">兑换</span>
            <input type="text" readonly="readonly" placeholder="7">
            <span class="change">梦币</span>
        </div>
        <div class="android">
            <span>Android</span>
            <input type="text" readonly="readonly" placeholder="1元">
            <span class="change">兑换</span>
            <input type="text" readonly="readonly" placeholder="10">
            <span class="change">梦币</span>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {

        }
    }
}
</script>
<style lang="scss" scoped>
#exchange_rate{
    background: #fff;
    h3{
        padding: 30px 0 30px 210px;
        font-weight: 700;
    }
    input{
        width: 260px;
        height: 30px;
        line-height: 30px;
        padding: 6px 12px;
        background: #eee;
    }
    .ios{
        padding-bottom: 15px;
        padding-left: 235px;
        span{
            padding-right: 20px;
            &.change{
                padding-left: 20px;
            }
        }
    }
    .android{
        padding-left: 210px;
        padding-bottom: 40px;
        span{
            padding-right: 20px;
            &.change{
                padding-left: 20px;
            }
        }
    }
}
</style>

