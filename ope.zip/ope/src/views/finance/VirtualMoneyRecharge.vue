<template>
    <div id="virtual_money_recharge">
        <div class="virtual-search">
            排序：
            <el-select v-model="value" placeholder="请选择">
                <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value">
                </el-option>
            </el-select>
            <input type="text" placeholder="请输入用户ID或用户昵称">
            <el-date-picker
            v-model="startDate"
            type="date"
            placeholder="选择日期">
            </el-date-picker>
            到
            <el-date-picker
            v-model="endDate"
            type="date"
            placeholder="选择日期">
            </el-date-picker>
            <el-select v-model="value1" placeholder="请选择">
                <el-option
                v-for="item in valueS"
                :key="item.value"
                :label="item.label"
                :value="item.value">
                </el-option>
            </el-select>
            <el-button type="primary">查询</el-button>
        </div>
        <div class="virtual_money_recharge_main">
            <el-table
            :data="tableData"
            stripe
            style="width: 100%">
                <el-table-column
                prop="order"
                label="序号">
                </el-table-column>
                <el-table-column
                prop="name"
                label="用户昵称">
                </el-table-column>
                <el-table-column
                prop="ments"
                label="用户ID">
                </el-table-column>

                <el-table-column
                prop="topuptime"
                label="充值时间"
                >
                </el-table-column>
                <el-table-column
                prop="topupmoney"
                label="充值金额">
                </el-table-column>
                 <el-table-column
                prop="topupproporation"
                label="充值比例">
                </el-table-column>
                 <el-table-column
                prop="topupway"
                label="充值方式">
                </el-table-column>
                 <el-table-column
                prop="getmentsmoney"
                label="获得梦币">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            startDate:'',
            endDate:'',
            options: [
                {
                    value: '选项1',
                    label: '充值时间'
                }, 
                {
                    value: '选项2',
                    label: '充值金额'
                }
            ],
            value:'充值时间',
            valueS:[
                 {
                    value: '选项1',
                    label: '充值流水'
                }, 
                {
                    value: '选项2',
                    label: '充值汇总'
                }
            ],
            value1:'充值流水',
            tableData: [
                {
                    order:'1',
                    name:'用户昵称',
                    ments:'21',
                    topuptime:'充值时间',
                    topupmoney:'充值金额',
                    topupproporation:'充值比例',
                    topupway:'充值方式',
                    getmentsmoney:'获得梦币'

                }, 
                {
                    order:'2',
                    name:'用户昵称',
                    ments:'21',
                    topuptime:'充值时间',
                    topupmoney:'充值金额',
                    topupproporation:'充值比例',
                    topupway:'充值方式',
                    getmentsmoney:'获得梦币'
                },
                {
                    order:'3',
                    name:'用户昵称',
                    ments:'21',
                    topuptime:'充值时间',
                    topupmoney:'充值金额',
                    topupproporation:'充值比例',
                    topupway:'充值方式',
                    getmentsmoney:'获得梦币'
                }, 
                {
                    order:'4',
                    name:'用户昵称',
                    ments:'21',
                    topuptime:'充值时间',
                    topupmoney:'充值金额',
                    topupproporation:'充值比例',
                    topupway:'充值方式',
                    getmentsmoney:'获得梦币'
            }]
        }
    }
}
</script>
<style lang="scss" scoped>
.virtual-search{
    text-align: right;
    input{
            display: inline-block;
            height: 30px;
            line-height: 30px;
            padding: 0 10px;
        }
        input::-webkit-input-placeholder{
            color:#ccc;
        }
        input::-moz-placeholder{   /* Mozilla Firefox 19+ */
            color:#ccc;
        }
        input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
            color:#ccc;
        }
        input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
            color:#ccc;
        }
}
.virtual_money_recharge_main{
    margin-top: 20px;
}
</style>

