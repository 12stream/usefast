<template>
    <div id="communication_fee_gift">
        <div class="gift-search">
            排序：
            <el-select v-model="value" placeholder="请选择">
                <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value">
                </el-option>
            </el-select>
            <input type="text" placeholder="请输入用户ID或用户昵称">
            <el-date-picker
            v-model="startDate"
            type="date"
            placeholder="选择日期">
            </el-date-picker>
            到
            <el-date-picker
            v-model="endDate"
            type="date"
            placeholder="选择日期">
            </el-date-picker>
            <el-select v-model="value1" placeholder="请选择">
                <el-option
                v-for="item in valueS"
                :key="item.value"
                :label="item.label"
                :value="item.value">
                </el-option>
            </el-select>
            <el-button type="primary">查询</el-button>
            <el-button type="primary">添加赠送</el-button>
            <el-button type="primary">赠送扣除</el-button>
        </div>
        <div class="communication_fee_gift_main">
            <el-table
            :data="tableData"
            stripe
            style="width: 100%">
                <el-table-column
                prop="name"
                label="用户昵称">
                </el-table-column>
                <el-table-column
                prop="ments"
                label="用户ID">
                </el-table-column>

                <el-table-column
                prop="givingtime"
                label="赠送时间"
                >
                </el-table-column>
                <el-table-column
                prop="givingmoney"
                label="赠送金额">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            startDate:'',
            endDate:'',
            options: [
                {
                    value: '选项1',
                    label: '赠送时间'
                }, 
                {
                    value: '选项2',
                    label: '赠送金额'
                }
            ],
            value:'赠送时间',
            valueS:[
                 {
                    value: '选项1',
                    label: '赠送流水'
                }, 
                {
                    value: '选项2',
                    label: '赠送汇总'
                }
            ],
            value1:'赠送流水',
            tableData: [
                {
                    name:'用户昵称',
                    ments:'21',
                    givingtime:'赠送时间',
                    givingmoney:'赠送金额'
                }, 
                {
                    name:'用户昵称',
                    ments:'21',
                    givingtime:'赠送时间',
                    givingmoney:'赠送金额'
                },
                {
                    name:'用户昵称',
                    ments:'21',
                    givingtime:'赠送时间',
                    givingmoney:'赠送金额'
                }, 
                {
                    name:'用户昵称',
                    ments:'21',
                    givingtime:'赠送时间',
                    givingmoney:'赠送金额'
            }]
        }
    }
}
</script>
<style lang="scss" scoped>
.gift-search{
    text-align: right;
    input{
            display: inline-block;
            height: 30px;
            line-height: 30px;
            padding: 0 10px;
        }
        input::-webkit-input-placeholder{
            color:#ccc;
        }
        input::-moz-placeholder{   /* Mozilla Firefox 19+ */
            color:#ccc;
        }
        input:-moz-placeholder{    /* Mozilla Firefox 4 to 18 */
            color:#ccc;
        }
        input:-ms-input-placeholder{  /* Internet Explorer 10-11 */ 
            color:#ccc;
        }
}
.communication_fee_gift_main{
    margin-top: 20px;
}
</style>

