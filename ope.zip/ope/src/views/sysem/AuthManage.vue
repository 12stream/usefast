<template>
    <div id="auth_manage">
        <div class="auth-search">
            <el-button type="primary" @click="addAuth">添加</el-button>
            <el-button type="primary">批量删除</el-button>
        </div>
        <div class="auth-main">
             <el-table
            :data="tableData">
                <el-table-column
                type="selection">
                </el-table-column>
                <el-table-column
                label="角色名称">
                <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.name }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="拥有权限">
                <template slot-scope="scope">
                    <span>{{ scope.row.hasroot}}</span>
                </template>
                </el-table-column>
                <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button
                    size="mini"
                    @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
                    <el-button
                    size="mini"
                    type="danger"
                    @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                </template>
                </el-table-column>
            </el-table>
        </div>
        <!-- 新增 -->
         <el-dialog title="编辑热词" :visible.sync="addAuthFlag">
            <div class="menuname">
                <span>　菜单名：</span>
                <input type="text">
            </div>
            <div class="menuaddr">
                <span>菜单地址：</span>
                <input type="text">
            </div>
            <div class="beforemenu">
                <span>上级菜单：</span>
                <input type="text">
            </div>
            <div class="shifoshow">
                <span>是否显示：</span>
                <input type="text">
            </div>
        <div slot="footer" class="dialog-footer">
            <el-button @click="addAuthFlag = false">取 消</el-button>
            <el-button type="primary" @click="addAuthFlag = false">确 定</el-button>
        </div>
        </el-dialog>
    </div>
</template>
<script>
export default {
    data(){
        return {
            addAuthFlag:false,
            isIndeterminate:true,
            checkAll:false,
            addAuthData:[],
            tableData: [
                {
                    name: '角色名称',
                    hasroot: '拥有权限'
                }, 
                {
                    name: '角色名称',
                    hasroot: '拥有权限'
                },
                {
                    name: '角色名称',
                    hasroot: '拥有权限'
                }, 
                {
                    name: '角色名称',
                    hasroot: '拥有权限'
            }]
        }
    },
    methods:{
        handleEdit(index, row) {
        console.log(index, row);
      },
      handleDelete(index, row) {
        console.log(index, row);
      },
      addAuth(){
          this.addAuthFlag = true;
      }
    }
}
</script>
<style lang="scss" scoped>
.auth-search{
    margin: 20px 0;
}
.menuname,.menuaddr,.menuorder,.beforemenu,.shifoshow{
    margin-top: 20px;
    span{
        margin-right: 20px;
    }
    input{
        border: 1px solid #ddd;
        padding: 10px;
        width: 80%;
    }
}
</style>

