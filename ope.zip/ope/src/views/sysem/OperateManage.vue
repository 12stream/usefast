<template>
    <div id="operate_manage">
        <div class="operate-search">
            <el-button type="primary" plain>添加</el-button>
            <el-button type="primary">批量删除</el-button>
        </div>
        <div class="operate-main">
             <el-table
            :data="tableData">
                <el-table-column
                type="selection">
                </el-table-column>
                <el-table-column
                label="用户名">
                <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.username }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="角色名称">
                <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.name }}</span>
                </template>
                </el-table-column>
                <el-table-column
                label="状态">
                <template slot-scope="scope">
                    <span>{{ scope.row.state}}</span>
                </template>
                </el-table-column>
                <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button
                    size="mini"
                    @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
                    <el-button
                    size="mini"
                    type="danger"
                    @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                </template>
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            isIndeterminate:true,
            checkAll:false,
            tableData: [
                {
                    username:'用户名',
                    name: '角色名称',
                    state: '状态'
                }, 
                {
                    username:'用户名',
                    name: '角色名称',
                    state: '状态'
                },
                {
                    username:'用户名',
                    name: '角色名称',
                    state: '状态'
                }, 
                {
                    username:'用户名',
                    name: '角色名称',
                    state: '状态'
            }]
        }
    },
    methods:{
        handleEdit(index, row) {
        console.log(index, row);
      },
      handleDelete(index, row) {
        console.log(index, row);
      }
    }
}
</script>
<style lang="scss" scoped>
.operate-search{
    margin: 20px 0;
}
</style>

