import Vue from 'vue'
import Router from 'vue-router'
// 登录页
import Login from '@/Login'

import Index from '@/Index'

// 数据概括
import User from '@/views/user/User'
// 用户管理
import UserManage from '@/views/user/UserManage'
import UserDetail from '@/views/user/UserDetail'
import UserHomepageManage from '@/views/user/UserHomepageManage'
import UserVideoManage from '@/views/user/UserVideoManage'
// 直播管理
import Live from '@/views/live/LiveManage'
// 点播管理
import Video from '@/views/video/VideoManage'
// 财务中心
import CommunicationFeeRecharge from '@/views/finance/CommunicationFeeRecharge'
import CommunicationFeeConsume from '@/views/finance/CommunicationFeeConsume'
import CommunicationFeeGift from '@/views/finance/CommunicationFeeGift'
import VirtualMoneyRecharge from '@/views/finance/VirtualMoneyRecharge'
import ExchangeRate from '@/views/finance/ExchangeRate'
// 数据统计
import UserCount from '@/views/data/UserCount'
import LiveAnchorNum from '@/views/data/LiveAnchorNum'
import FinanceCount from '@/views/data/FinanceCount'
import CdnBandwidthReal from '@/views/data/cdn/CdnBandwidthReal'
import CdnBandwidthHistory from '@/views/data/cdn/CdnBandwidthHistory'
// 运营工具
import BusinessManage from '@/views/business/BusinessManage'
import WithdrawManage from '@/views/business/WithdrawManage'
import ChargeSet from '@/views/business/ChargeSet'
import EntranceTicketManage from '@/views/business/EntranceTicketManage'
import AppSet from '@/views/business/AppSet'
import BannerManage from '@/views/business/BannerManage'
import HotAnchor from '@/views/business/HotAnchor'
import IdCheck from '@/views/business/IdCheck'
import ContentCommend from '@/views/business/ContentCommend'
import MessagepushManage from '@/views/business/MessagepushManage'
import SmsManage from '@/views/business/SmsManage'
import HotwordManage from '@/views/business/HotwordManage'
import TipoffManage from '@/views/business/TipoffManage'
import FeedbackManage from '@/views/business/FeedbackManage'
import WatermarkManage from '@/views/business/WatermarkManage'
// 账号权限
import AuthManage from '@/views/sysem/AuthManage'
import OperateManage from '@/views/sysem/OperateManage'


var Obj = [
  {
    path: '/user/root_index',
    name: 'user',
    component: User,
    meta: {
      title:'数据概览',
    }
  },
  {
    path: '/user/user_manage',
    name: 'user-manage',
    component: UserManage,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/user/user_detail',
    name: 'user-detail',
    component: UserDetail,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/user/user_homepage_manage',
    name: 'user-homepage-manage',
    component: UserHomepageManage,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/user/user_video_manage',
    name: 'user_video_manage',
    component: UserVideoManage,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/live',
    name: 'live',
    component: Live,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/video',
    name: 'video',
    component: Video,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/finance/communication_fee_recharge',
    name: 'communication_fee_recharge',
    component: CommunicationFeeRecharge,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/finance/communication_fee_consume',
    name: 'communication_fee_consume',
    component: CommunicationFeeConsume,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/finance/communication_fee_gift',
    name: 'communication_fee_gift',
    component: CommunicationFeeGift,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/finance/virtual_money_recharge',
    name: 'virtual_money_recharge',
    component: VirtualMoneyRecharge,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/finance/exchange_rate',
    name: 'exchange_rate',
    component: ExchangeRate,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/data/user_count',
    name: 'user_count',
    component: UserCount,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/data/live_anchor_num',
    name: 'live_anchor_num',
    component: LiveAnchorNum,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/data/finance_count',
    name: 'finance_count',
    component: FinanceCount,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/data/cdn_bandwidth_real',
    name: 'cdn_bandwidth_real',
    component: CdnBandwidthReal,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/data/cdn_bandwidth_history',
    name: 'cdn_bandwidth_history',
    component: CdnBandwidthHistory,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/business/business_manage',
    name: 'business_manage',
    component: BusinessManage,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/withdraw/withdraw_manage',
    name: 'withdraw_manage',
    component: WithdrawManage,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/system/charge_set',
    name: 'charge_set',
    component: ChargeSet,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/entrance_ticket/entrance_ticket_manage',
    name: 'entrance_ticket_manage',
    component: EntranceTicketManage,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/system/app_set',
    name: 'app_set',
    component: AppSet,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/banner/banner_manage',
    name: 'banner_manage',
    component: BannerManage,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/user/hot_anchor',
    name: 'hot_anchor',
    component: HotAnchor,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/user/id_check',
    name: 'id_check',
    component: IdCheck,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/live_room/content_commend',
    name: 'content_commend',
    component: ContentCommend,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/messagepush/messagepush_manage',
    name: 'messagepush_manage',
    component: MessagepushManage,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/messagepush/sms_manage',
    name: 'sms_manage',
    component: SmsManage,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/hotword/hotword_manage',
    name: 'hotword_manage',
    component: HotwordManage,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/tipoffcenter/tipoff_manage',
    name: 'tipoff_manage',
    component: TipoffManage,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/feedback/feedback_manage',
    name: 'feedback_manage',
    component: FeedbackManage,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/license/watermark_manage',
    name: 'watermark_manage',
    component: WatermarkManage,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/system/auth_manage',
    name: 'auth_manage',
    component: AuthManage,
    meta: {
      title:'用户管理',
    }
  },
  {
    path: '/system/operate_manage',
    name: 'operate_manage',
    component: OperateManage,
    meta: {
      title:'用户管理',
    }
  }
]
Vue.use(Router)
const router = new Router({
  routes: [
    {
      path: '/login',
      name: 'Login',
      component: Login
    },
    {
      path: '/',
      name: 'index',
      component: Index,
      children:Obj
    }
  ]
})
export default router
