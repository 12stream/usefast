<template>
    <div id="left-menu">
        <div class="user-title">
            <h2>欢迎，root</h2>
            <p>
                <span>安全退出</span>
                <img :src="setImg" alt="404" @mouseover="setOver" @mouseout="setOut" @click="dialogFormVisible = true">
            </p>
        </div>
        <!-- <ul>
            <li v-for="(item,i) in Menu" :key="i" @click="showSecMenu(item,i)" :class="item.sec ? (item.showF ? 'bac hov' : 'bac') : ''">
                <span :class="item.sec ? (item.showF ? 'tri an' : 'tri') : ''">
                    <i><img :src="item.actImg"></i>
                    {{item.f}}
                    <ul v-show="item.showF">
                        <li v-for="(val,j) in item.sec" :key="j" @click.stop="showSecMenu2(val,j)" :class="[val.tirRouter ? (showT ? 'stri sub' : 'stri') : '', secIndex == j ? clickColor : '']">
                            {{val.name}}
                            <span v-if="val.tirRouter">
                                <ul v-if="showT">
                                    <li v-for="(res,k) in val.tirRouter" :key="k" @click.stop="showSecMenu3(res)">
                                        {{res.tirName}}
                                    </li>
                                </ul>
                            </span>
                        </li>
                        <li v-for="(val,j) in item.sec" :key="j" @click.stop="showSecMenu2(val,j)" :class="[val.tirRouter ? 'stri'  : '', secIndex == j ? clickColor : '']">
                            {{val.name}}
                        </li>
                    </ul> 
                </span>
            </li>
        </ul> -->
        <el-menu
        default-active="0"
        class="el-menu-router" @open="handleOpen()">
            <el-menu-item v-for="(item,i) in Menu" :key="i" :index="i+''+1" @click="showSecMenu(item,i)" :class="item.sec ? (item.showF ? 'bac hov' : 'bac') : 'onec'" v-show='!item.sec'>
                <i><img :src="item.actImg"></i>
                <span slot="title">
                    {{item.f}}
                </span>
            </el-menu-item>
            <el-submenu v-for="(item,i) in Menu" :key="i + 'm'" :index="i+''+1" @click="showSecMenu(item,i)" :class="item.sec ? (item.showF ? 'bac hov' : 'bac') : ''" v-show='item.sec'>
                <template slot="title">
                <i><img :src="item.actImg"></i>
                <span>{{item.f}}</span>
                </template>
                <el-menu-item-group>
                    <el-menu-item v-for="(val,j) in item.sec" :index="i + '-' + (j+1)" :key="i + '' + j" @click="showSecMenu2(val,j)">{{val.name}}</el-menu-item>
                </el-menu-item-group>
            </el-submenu>
        </el-menu>
        <el-dialog title="修改密码" :visible.sync="dialogFormVisible">
        <el-form :model="form">
            <el-form-item label="原密码" :label-width="formLabelWidth">
                <el-input v-model="form.startpassword" placeholder="请输入旧密码"></el-input>
            </el-form-item>
            <el-form-item label="新密码" :label-width="formLabelWidth">
                <el-input v-model="form.newpassword" placeholder="请输入新密码"></el-input>
            </el-form-item>
            <el-form-item label="确认密码" :label-width="formLabelWidth">
                <el-input v-model="form.comfirmpassword" placeholder="请再次输入新密码"></el-input>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
        </div>
        </el-dialog>
    </div>
</template>
<script>
import eventVue from '@/components/eventVue.js'
export default {
    data(){
        return {
            dialogFormVisible:false,
            Flag:false,
            showT:false,
            secIndex:0,
            curIndex:0,
            clickColor:'showcolor',
            setImg:require('./images/set.png'),
            Menu:[
                {
                    f:'数据概览',
                    routerS:'/user/root_index',
                    showF:false,
                    actImg:require('./images/summary.png')
                },
                {
                    f:'用户管理',
                    routerS:'/user/user_manage',
                    showF:false,
                    actImg:require('./images/user.png')
                },
                {
                    f:'直播管理',
                    routerS:'/live',
                    showF:false,
                    actImg:require('./images/live.png')
                },
                {
                    f:'点播管理',
                    routerS:'/video',
                    showF:false,
                    actImg:require('./images/video.png')
                },
                {
                    f:'财务中心',
                    sec:[
                        {
                            name:'充值记录',
                            routerS:'/finance/communication_fee_recharge'
                        },
                        {
                            name:'消费记录',
                            routerS:'/finance/communication_fee_consume'
                        },
                        {
                            name:'赠送记录',
                            routerS:'/finance/communication_fee_gift'
                        },
                        {
                            name:'虚拟货币充值',
                            routerS:'/finance/virtual_money_recharge'
                        },{
                            name:'兑换比例设置',
                            routerS:'/finance/exchange_rate'
                        }
                    ],
                    showF:false,
                    actImg:require('./images/financial.png')
                },
                {
                    f:'数据统计',
                    sec:[
                        {
                            name:'用户统计',
                            routerS:'/data/user_count'
                        },
                        {
                            name:'直播统计',
                            routerS:'/data/live_anchor_num'
                        },
                        {
                            name:'财务统计',
                            routerS:'/data/finance_count'
                        },
                        {
                            name:'实时数据',
                            routerS:'/data/cdn_bandwidth_real'
                        },
                            {
                            name:'历史数据',
                            routerS:'/data/cdn_bandwidth_history'
                        }
                        // {
                        //     name:'CDN统计',
                        //     tirRouter:[
                        //         {
                        //             tirName:'实时数据',
                        //             routerS:'/data/cdn_bandwidth_real'
                        //         },
                        //          {
                        //             tirName:'历史数据',
                        //             routerS:'/data/cdn_bandwidth_history'
                        //         }
                        //     ]
                        // }
                    ],
                    showF:false,
                    actImg:require('./images/data.png')
                },
                {
                    f:'运营工具',
                    sec:[
                        {
                            name:'商务管理',
                            routerS:'/business/business_manage'
                        },
                        {
                            name:'提现管理',
                            routerS:'/withdraw/withdraw_manage'
                        },
                        {
                            name:'收费设置',
                            routerS:'/system/charge_set'
                        },
                        {
                            name:'门票管理',
                            routerS:'/entrance_ticket/entrance_ticket_manage'
                        },
                        {
                            name:'APP风格设置',
                            routerS:'/system/app_set'
                        },
                        {
                            name:'轮播图管理',
                            routerS:'/banner/banner_manage'
                        },
                        {
                            name:'默认关注管理',
                            routerS:'/user/hot_anchor'
                        },
                        {
                            name:'身份认证审核',
                            routerS:'/user/id_check'
                        },
                        {
                            name:'内容推荐',
                            routerS:'/live_room/content_commend'
                        },
                        {
                            name:'消息推送',
                            routerS:'/messagepush/messagepush_manage'
                        },
                        {
                            name:'短信管理',
                            routerS:'/messagepush/sms_manage'
                        },
                        {
                            name:'热词管理',
                            routerS:'/hotword/hotword_manage'
                        },
                        {
                            name:'举报中心',
                            routerS:'/tipoffcenter/tipoff_manage'
                        },
                        {
                            name:'建议与反馈',
                            routerS:'/feedback/feedback_manage'
                        },
                         {
                            name:'牌照水印管理',
                            routerS:'/license/watermark_manage'
                        }
                    ],
                    showF:false,
                    actImg:require('./images/operation.png')
                },
                {
                    f:'帐号权限',
                    sec:[
                        {
                            name:'角色权限',
                            routerS:'/system/auth_manage'
                        },
                        {
                            name:'操作员管理',
                            routerS:'/system/operate_manage'
                        }
                    ],
                    showF:false,
                    actImg:require('./images/permission.png')
                }
            ],
            gridData: [{
                date: '2016-05-02',
                name: '王小虎',
                address: '上海市普陀区金沙江路 1518 弄'
            }, {
                date: '2016-05-04',
                name: '王小虎',
                address: '上海市普陀区金沙江路 1518 弄'
            }, {
                date: '2016-05-01',
                name: '王小虎',
                address: '上海市普陀区金沙江路 1518 弄'
            }, {
                date: '2016-05-03',
                name: '王小虎',
                address: '上海市普陀区金沙江路 1518 弄'
            }],
            dialogTableVisible: false,
            dialogFormVisible: false,
            form: {
                startpassword: '',
                newpassword:''
            },
            formLabelWidth: '120px'
        }
    },
    methods:{
        setOver(){
            this.setImg = require('./images/set-hover.png');
        },
        setOut(){
            this.setImg = require('./images/set.png');
        },
          showSecMenu(val,num){
              this.Menu.map((item,i) =>{
                  if(num == i){
                      this.Menu[num].showF = !this.Menu[num].showF;
                  }else{
                      item.showF = false;
                  }
              })
              if(val.sec){
                this.curIndex = num;
                this.Flag = !this.Flag;
              }else{
                  eventVue.$emit('menuTitle',val.f);
              }
              if(val.routerS){
                  this.$router.push({path:val.routerS});
              }
          },
          showSecMenu2(val,index){
              this.secIndex = index;
              eventVue.$emit('menuTitle',val.name);
              if(val.routerS){
                  this.$router.push({path:val.routerS});
              }
            //   if(val.tirRouter){
            //       this.showT = !this.showT;
            //   }
          },
          showSecMenu3(val){
              eventVue.$emit('menuTitle',val.tirName);
               if(val.routerS){
                  this.$router.push({path:val.routerS});
              }
          },
        //   用户设置
        userSet(){
            alert(12)
        },
        handleOpen(){
            // console.log(key,value);
        }  
    }
}
</script>
<style lang="scss" scoped>
    #left-menu {
        background: #161B37;
        .user-title{
            padding: 33px 25px;
            h2{
                font-size: 18px;
                font-weight:bold;
            }
            p{
                margin-top: 24px;
                span{
                    display: inline-block;
                    width:68px;
                    height:24px;
                    border:1px solid rgba(24,144,255,1);
                    border-radius:2px;
                    font-size:12px;
                    font-family:PingFangSC-Medium;
                    font-weight:500;
                    color:rgba(24,144,255,1);
                    line-height:24px;
                    text-align: center;
                }
                img{
                    width: 24px;
                    height: 24px;
                    float: right;
                }
            }
        }
        .el-menu-router{
            background: #161B37;
            li{
                span{
                    color:#fff;
                }
            }
        }
        // ul{
        //     li{
        //         width: 100%;
        //         padding: 14px 20px 14px 25px;
        //         position: relative;
        //         .tri:after{
        //             content: "";
        //             border-top: 1px solid #fff;
        //             border-right: 1px solid #fff;
        //             width: 5px;
        //             height: 5px;
        //             position: absolute;
        //             right: 20px;
        //             top: 26px;
        //             transform: rotate(-45deg);
        //             margin-left: 10px;
        //             margin-top: -4px;
        //         }
        //         &.bac {
        //             padding: 14px 0;
        //             &.hov{
        //                padding-bottom: 0;
        //             }
        //             span{
        //                padding-left: 25px;
        //             }
        //         }
        //         .tri.an:after{
        //             transform: rotate(135deg);
        //         }
        //         ul {
        //             background: #0D111F;
        //             li{
        //                 padding-left: 53px;
        //                 &.showcolor{
        //                     color: #1890FF;
        //                 }
        //                 &.stri:after{
        //                     content: "";
        //                     border-top: 1px solid #fff;
        //                     border-right: 1px solid #fff;
        //                     width: 5px;
        //                     height: 5px;
        //                     position: absolute;
        //                     right: 20px;
        //                     top: 26px;
        //                     transform: rotate(-45deg);
        //                     margin-left: 10px;
        //                     margin-top: -4px;
        //                 }
        //                 &.stri.sub:after{
        //                     transform: rotate(135deg);
        //                 }
        //                 ul{
        //                     li{
        //                         padding-left: 20px;
        //                         color: #fff;
        //                     }
        //                 }
        //             }
        //             li:hover{
        //                 background: #0D111F;
        //                 color: #1890FF;
        //             }
        //         }
        //     }
        //     // li:nth-of-type(1){
        //     //     padding-top: 10px;
        //     // }
        //     >li:hover{
        //         background: #1890FF;
        //     }
        // }
    }
    // .el-submenu.bac:hover{
    //     .el-submenu__title:hover {
    //         background-color: #1890FF !important;
    //     }
    // }
    
</style>


