<template>
    <div id="header">
        <div>{{showMenuTitle}}</div>
    </div>
</template>
<script>
import eventVue from '@/components/eventVue.js'
export default {
    data(){
        return {
            showMenuTitle:'数据概括'
        }
    },
    mounted(){
        eventVue.$on('menuTitle',val =>{
            this.showMenuTitle = val;
        })
    }
}
</script>
<style lang="scss" scoped>
    #header{
        background: #fff;
        padding: 0;
        height: 64px;
        line-height: 64px;
        padding-left: 24px;
        font-size:14px;
    }
</style>

